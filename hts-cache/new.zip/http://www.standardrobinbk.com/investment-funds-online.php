﻿<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8">

<head>
	<title>Investment Funds Online | StandardRobin</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<!-- Favicon icon -->
	<link rel="stylesheet" href="site.min.css" type="text/css">
	<link rel="shortcut icon" type="image/png" href="images\favicon.png">
	<!-- Google fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,400,400i,500,500i,700" rel="stylesheet">
	<!-- Bootstrap -->
	<link href="css\bootstrap.min.css" rel="stylesheet">
	<!-- Fontawsome -->
	<link href="css\font-awesome.min.css" rel="stylesheet">
	<!-- Animate CSS-->
	<link href="css\animate.css" rel="stylesheet">
	<!-- menu CSS-->
	<link href="css\bootstrap-4-navbar.css" rel="stylesheet">
	<!-- Portfolio Gallery -->
	<link href="css\filterizer.css" rel="stylesheet">
	<!-- Lightbox Gallery -->
	<link href="inc\lightbox\css\jquery.fancybox.css" rel="stylesheet">
	<!-- OWL Carousel -->
	<link rel="stylesheet" href="css\owl.carousel.min.css">
	<link rel="stylesheet" href="css\owl.theme.default.min.css">
	<!-- Preloader CSS-->
	<link href="css\fakeLoader.css" rel="stylesheet">
	<!-- Main CSS -->
	<link rel="stylesheet" type="text/css" href="css/sweetalert.css">
	<link href="style.css" rel="stylesheet">
	<!-- Default CSS Color -->
	<link href="color\default.css" rel="stylesheet">
	<!-- Color CSS -->
	<link rel="stylesheet" href="color/color-switcher.css">
	<!-- Default CSS Color -->
	<link href="color\default.css" rel="stylesheet">
	<!-- Color CSS -->
	<link rel="stylesheet" href="color\color-switcher.css">
	<!-- Responsive CSS -->
	<link href="css\responsive.css" rel="stylesheet">
	<link href="css\customcss.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/toastr.css">

</head>
<!--header open in header-->


<body>
    <style>
        .navbar-brand h2 {
            font-size: 35px;
            margin-top: 2px;
        }
    </style>
    <!-- Preloader -->
	<div id="fakeloader"></div>

<div class="top-menu-1x">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="top-menu-left">
                    <p>Need help? Contact Us</p>

                    <b><i class="fa fa-envelope"></i><a style="color:#fff;" href="mailto:"></a></b>
                </div>
            </div>
            <div class="col-md-6">
                <div class="top-menu-right">
                    <div class="footer-info-right">
                        <ul>
                            <a href="secure/customer_login" style="background-color:white; color:black; border: 2px red; padding:2px;"><i class="fa fa-lock"></i> sign in</a>
                            <li><a href="#"> <i class="fa fa-twitter"></i> </a></li>
                            <li><a href="#"> <i class="fa fa-google"></i> </a></li>
                            <li><a href="#"> <i class="fa fa-linkedin"></i> </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

   
    <div class="bussiness-main-menu-1x">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="business-main-menu">
						<nav class="navbar navbar-expand-lg navbar-light bg-light btco-hover-menu">
							<a class="navbar-brand" href="/">
								<img style="max-width:125px;" src="logo.png" class="d-inline-block align-top" alt="">
								<!--<h2><span style="color:#EC4550;">I</span><span style="color:#0E3768;">BG</span></h2>-->
							</a>
							<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
								<span class="navbar-toggler-icon"></span>
							</button>

							<div class="collapse navbar-collapse" id="navbarSupportedContent">

								<ul class="navbar-nav ml-auto business-nav">
									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Banking Services <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Accounts & services</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav1">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="current-accounts.php" class="menuhead">Current Accounts</a>
																				<li><a class="dropdown-item" href="premier-accounts.php">StanRob Account</a></li>
																				<li><a class="dropdown-item" href="advance-accounts.php">Advance Account</a></li>
																				<li><a class="dropdown-item" href="student-accounts.php">Student Account</a></li>
																				<li><a class="dropdown-item" href="bank-accounts.php">Bank Account</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="saving-accounts.php" class="menuhead">Savings</a>
																				<li><a class="dropdown-item" href="isas-accounts.php">ISAs</a></li>
																				<li><a class="dropdown-item" href="online-bonus-saver.php">Online Bonus Saver</a></li>
																				<li><a class="dropdown-item" href="flexible-saver.php">Flexible Saver</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="../credit-cards" class="menuhead">Credit cards</a>
																				<li><a class="dropdown-item" href="32-month-balance-transfer">32 Month Transfer Credit Card</a></li>
																				<li><a class="dropdown-item" href="advance.php">Advance Credit Card</a></li>
																				<li><a class="dropdown-item" href="dual.php">Dual Credit Card</a></li>
																				<li><a class="dropdown-item" href="classic.php">Classic Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier.php">StanRob Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier-world-elite.php">StanRob World Elite Mastercard</a></li>
																				<li><a class="dropdown-item" href="student.php">Student Credit Card</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Services</a>
																				<li><a class="dropdown-item" href="ways-to-bank.php">Ways to bank</a></li>
																				<li><a class="dropdown-item" href="phone-banking.php">Voice ID</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">Contact & Support</a></li>
																				<li><a class="dropdown-item" href="branch-locator.php">Find a Branch</a></li>
																				<a style="margin-top: 15px;" href="international.php" class="menuhead">International services</a>
																				<li><a class="dropdown-item" href="currency-account.php">Currency Account</a></li>
																				<li><a class="dropdown-item" href="money-transfer.php">International Payments</a></li>
																				<li><a class="dropdown-item" href="travel-money.php">Travel money</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>
									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Borrowing <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Loans & mortgages</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav2">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="loans" class="menuhead">Loans</a>
																				<li><a class="dropdown-item" href="personal-loans.php">Personal Loan</a></li>
																				<li><a class="dropdown-item" href="car-loans.php">Car Loan</a></li>
																				<li><a class="dropdown-item" href="flexible.php">Flexiloan</a></li>
																				<li><a class="dropdown-item" href="premier-personal.php">StanRob Personal Loan</a></li>
																				<li><a class="dropdown-item" href="graduate-loans.php">Graduate Loan</a></li>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="overdrafts" class="menuhead">Overdrafts</a>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="mortgages" class="menuhead">Mortgages</a>
																				<li><a class="dropdown-item" href="first-time-buyers.php">First time buyer</a></li>
																				<li><a class="dropdown-item" href="95-mortgages.php">95% Mortgages</a></li>
																				<li><a class="dropdown-item" href="remortgage.php">Remortgage</a></li>
																				<li><a class="dropdown-item" href="buy-to-let-mortgages.php">Buy to let</a></li>
																				<li><a class="dropdown-item" href="existing-customers.php">Existing homeowner</a></li>
																				<li><a class="dropdown-item" href="mortgage-rates.php">Mortgage rates</a></li>
																				<li><a class="dropdown-item" href="armed-forces.php">Armed Forces Personnel</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="../credit-cards" class="menuhead">Credit cards</a>
																				<li><a class="dropdown-item" href="32-month-balance-transfer.php">32 Month Transfer Credit Card</a></li>
																				<li><a class="dropdown-item" href="advance.php">Advance Credit Card</a></li>
																				<li><a class="dropdown-item" href="dual.php">Dual Credit Card</a></li>
																				<li><a class="dropdown-item" href="classic.php">Classic Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier.php">StanRob Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier-world-elite.php">StanRob World Elite Mastercard</a></li>
																				<li><a class="dropdown-item" href="student.php">Student Credit Card</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Services</a>
																				<li><a class="dropdown-item" href="contactandsupport.php">Help & Support</a></li>
																				<li><a class="dropdown-item" href="money-worries.php">Money Worries</a></li>
																				<li><a class="dropdown-item" href="branch-locator.php">Find a Branch</a></li>

																				<a style="margin-top: 15px;" href="tools-and-guides.php" class="menuhead">Tools & Guides</a>
																				<li><a class="dropdown-item" href="overpayment-calculator.php">Overpayment calculator</a></li>
																				<li><a class="dropdown-item" href="repayment-calculator.php">Repayment calculator</a></li>
																				<li><a class="dropdown-item" href="bank-of-england-base-rate.php">Base rate information</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Investing <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Products & analysis</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav3">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="investing" class="menuhead">Investments</a>
																				<li><a class="dropdown-item" href="investment-funds.php">Investment funds</a></li>
																				<li><a class="dropdown-item" href="world-selection-isa.php">World Selection ISA</a></li>
																				<li><a class="dropdown-item" href="sharedealing.php">Sharedealing</a></li>
																				<li><a class="dropdown-item" href="premier-financial-advice.php">StanRob Financial Advice</a></li>
																				<li><a class="dropdown-item" href="stand-alone-investment-advice.php">Stand-alone Investment Advice</a></li>
																				<li><a class="dropdown-item" href="onshore-investment-bond.php">Onshore Investment Bond</a></li>
																				<li><a class="dropdown-item" href="child-trust-funds.php">Child Trust fund</a></li>
																				<li><a class="dropdown-item" href="investing.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="news.php" class="menuhead">Financial news & analysis</a>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="why-invest-with-us.php" class="menuhead">Why invest with us?</a>
																				<li><a class="dropdown-item" href="why-invest-with-u.phps">Find out more</a></li>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="wealth-insights.php" class="menuhead">Wealth Insights </a>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="investment-funds-online.php" class="menuhead">Global Investment Centre</a>
																				<li><a class="dropdown-item" href="investment-funds-online.php">Find out more</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport" class="menuhead">Customer support</a>
																				<li><a class="dropdown-item" href="gsa.php">Log on to Global Investment<br>Centre</a></li>
																				<li><a class="dropdown-item" href="gsa.php">Log on to Sharedealing</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">Investments contacts</a></li>
																				<li><a class="dropdown-item" href="selected-investment-funds.php">Existing Selected Investments<br>Customers</a></li>
																				<li><a class="dropdown-item" href="getting-started.php">Getting started with investing</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Insurance <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Property & family</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav4">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="insurance.php" class="menuhead">Insurance</a>
																				<li><a class="dropdown-item" href="home-insurance.php">Home Insurance</a></li>
																				<li><a class="dropdown-item" href="travel-insurance.php">Travel Insurance</a></li>
																				<li><a class="dropdown-item" href="student-insurance.php">Student Insurance</a></li>
																				<li><a class="dropdown-item" href="insurance.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="life-insurance.php" class="menuhead">Life Insurance</a>
																				<li><a class="dropdown-item" href="life-cover.php">Life Cover</a></li>
																				<li><a class="dropdown-item" href="critical-illness-cover.php">Critical Illness Cover</a></li>
																				<li><a class="dropdown-item" href="income-cover.php">Income Cover</a></li>
																				<li><a class="dropdown-item" href="protection-telephone-advice.php">Telephone Protection Advice</a></li>
																				<li><a class="dropdown-item" href="life-insurance.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="insurance.php" class="menuhead">Insurance Claims</a>
																				<li><a class="dropdown-item" href="home-insurance-claims.php">Home Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="travel-insurance.php">Travel Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="car-insurance-claims.php">Car Insurance Claims</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="premier-accounts.php" class="menuhead">StanRob Customers</a>
																				<li><a class="dropdown-item" href="premier-travel.php">Travel Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="premier-car.php">Car Insurance Claims</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Life events <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Help & support</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav5">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="life-events.php" class="menuhead">Life events</a>
																				<li><a class="dropdown-item" href="dealing-with-bereavement.php">Bereavement support</a></li>
																				<li><a class="dropdown-item" href="dealing-with-separation.php">Separation support</a></li>
																				<li><a class="dropdown-item" href="settling-in-the-uk.php">Settling in the UK</a></li>
																				<li><a class="dropdown-item" href="getting-married.php">Getting married</a></li>
																				<li><a class="dropdown-item" href="planning-your-retirement.php">Planning your retirement</a></li>
																				<li><a class="dropdown-item" href="growing-your-wealth.php">Growing your wealth</a></li>
																				<li><a class="dropdown-item" href="moving-abroad.php">Moving abroad</a></li>
																				<li><a class="dropdown-item" href="life-events.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="planningtools.php" class="menuhead">Planning tools</a>
																				<li><a class="dropdown-item" href="financial-health-check.php">Financial health check</a></li>
																				<li><a class="dropdown-item" href="planningtools.php">View All</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="protecting-what-matters.php" class="menuhead">Protecting what matters</a>
																				<li><a class="dropdown-item" href="protecting-what-matters.php">Learn more</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Customer support</a>
																				<li><a class="dropdown-item" href="ways-we-can-help.php">Ways we can help</a></li>
																				<li><a class="dropdown-item" href="money-worries.php">Money Worries</a></li>
																				<li><a class="dropdown-item" href="ways-we-can-help.php">Frequently asked questions</a></li>
																				<a style="margin-top: 15px;" href="quality-conversations.php" class="menuhead">Individual Review</a>
																				<li><a class="dropdown-item" href="quality-conversations.php">Book your review today for a<br>quick financial checkup</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

								</ul>
							</div>
						</nav>
					</div>
				</div>
			</div>
		</div> 
	</div>
	<!--NAVIGATION END--> <!-- content start-->
	
    <style>
        #userpinid,
        #useridtextid {
            color: #717171;
            font-size: 1em;
            line-height: 1.375em;
            background: none;
            border: none;
            border-bottom-color: currentcolor;
            border-bottom-style: none;
            border-bottom-width: medium;
            border-bottom-color: currentcolor;
            border-bottom-style: none;
            border-bottom-width: medium;
            border-bottom: 1px solid #ccc;
            padding: .313em;
            margin: .188em 0;
        }
    </style><!--NAVIGATION END--> <!-- content start-->
<style type="text/css">
	.item.creditbanner {
		position: relative;
	}

	.banner-content {
		position: absolute;
		top: 45%;
		left: 9%;
		background-color: #fff;
		padding: 30px 30px 30px 30px;
		box-shadow: 0 0 23px -5px #000;
		width: auto;
	}

	.banner-content h3 {
		color: #033d75;
		font-size: 28px;
		text-transform: uppercase;
		margin-bottom: 15px;
		font-weight: bold;
	}

	.banner-content p {
		color: #333;
		font-size: 20px;
		margin-bottom: 0;
	}

	.cardWr.row {
		box-shadow: 0 0 15px -3px #000;
		margin: 60px 0;
		border-radius: 0;
	}

	.single-bolg.hover01 a:hover .blog-content {
		color: #EF454D;
		transition: all .5s ease 0s;
	}

	.cardWr .col-sm-8 {
		padding: 30px;
	}

	.cardWr .col-sm-4 {
		padding: 40px 30px 30px;
	}

	.cardWr .col-sm-4 {
		background-color: #033d75;
		color: #fff;
	}

	.cardWr .col-sm-4 .col-sm-12 {
		padding: 0;
	}

	.cardWr .col-sm-12 p {
		margin: 8px 0 15px;
		font-size: 18px;
	}

	.cardWr .col-sm-12 h2 {
		font-size: 22px;
		font-weight: bold;
		color: #033d75;
		margin-bottom: 17px;
		margin-top: 15px;
		text-transform: uppercase;
	}

	.inner-card-wr .fa.fa-check {
		margin-right: 10px;
	}

	.cardWr .col-sm-12 ul,
	.inner-card-wr ul {
		padding-left: 0;
	}

	.inner-card-wr li {
		font-weight: bold;
	}

	.inner-card-wr ul p {
		margin-left: 29px;
		margin-bottom: 18px;
	}

	.card-single-wr h2 {
		font-size: 30px;
		position: relative;
		margin-left: 20px;
		margin-bottom: 30px;
		color: #033d75;
	}

	.card-single-wr h2::before {
		position: absolute;
		left: -25px;
		top: 0;
		width: 5px;
		height: 32px;
		background-color: #EF454D;
		content: '';
	}

	.inner-card-wr h3 {
		margin-bottom: 23px;
		font-size: 24px;
		margin-top: 40px;
		font-weight: bold;
		color: #EF454D;
	}

	.cardWr .col-sm-12 li,
	.inner-card-wr li {
		display: block;
		margin-bottom: 14px;
	}

	.card-single-wr {
		border-top: 1px solid #033d75;
		padding: 45px 0 22px;
	}

	.inner-card-wr p a {
		color: #033d75;
		text-decoration: underline;
	}

	.firstspan {
		width: 4%;
		display: inline-block;
		vertical-align: top;
	}

	.secondspan {
		display: inline-block;
		width: 90%;
		vertical-align: top;
	}

	.rightwr .col-sm-12 p {
		font-size: 20px;
		line-height: 30px;
		margin-bottom: 20px;
	}

	.col-sm-12.variableper {
		margin-top: 10px;
	}

	p span {
		display: block;
		font-size: 16px;
	}

	.readmoreWr {
		text-align: left;
		margin: 20px 0 20px;
		padding-left: 15px;
	}

	.fa.fa-info-circle {
		margin-right: 10px;
	}

	i.fa.fa-check {
		color: #033d75;
		font-size: 19px;
	}

	.inner-card-wr.lowerwr ul {
		margin: 5px 0;
	}

	i.fa.fa-download {
		margin-right: 10px;
		color: #033d75;
	}

	.inner-card-wr.lowerwr li {
		font-weight: normal;
	}

	.inner-card-wr.lowerwr li a {
		color: #033d75;
	}

	.inner-card-wr.lowerwr li a:hover {
		color: #EF454D;
	}

	.toggleclass {
		color: #333;
		font-size: 18px;
		font-weight: bold;
		text-decoration: underline;
		margin-bottom: 25px;
		display: inline-block;
	}

	.toggleclass:hover {
		text-decoration: underline;
	}

	.logonwr {
		margin-bottom: 35px;
	}

	.collapse h3 a {
		color: #033d75;
	}

	.business-wr {
		padding: 0;
		margin-top: 40px;
	}

	.blog-content {
		font-size: 20px;
		margin-top: 15px;
		text-align: left;
		margin-bottom: 22px;
		min-height: auto;
		color: #033d75;
	}

	.single-bolg.hover01 {
		margin-top: 0;
	}

	#demo1 .col-sm-6 h3 {
		margin-top: 0;
	}

	.anchorlink a {
		color: #fff;
		text-decoration: underline;
	}

	.bottomimg .blog-content {
		text-align: center;
	}
</style>

<div class="business-main-slider">
	<div class="owl-carousel main-slider">
		<div class="item creditbanner">
			<div class="hvrbox">
				<img src="images\cherries.jpg" alt="credit" class="hvrbox-layer_bottom">
			</div>
			<div class="banner-content">
				<div class="innerBanner container">
					<h3>Global Investment Centre</h3>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="card-detail-wr" style="margin-bottom: 30px;">
	<div class="container">
		<div class="card-single-wr" style="border-top: none;">
			<div class="tkl">
				<style>
					.tab {
						overflow: hidden;
						border: 1px solid #ccc;
						background-color: #033d75;
					}

					/* Style the buttons inside the tab */
					.tab button {
						background-color: inherit;
						float: left;
						border: none;
						outline: none;
						cursor: pointer;
						padding: 14px 16px;
						transition: 0.3s;
						font-size: 20px;
						color: #fff;
						border-radius: 0;
					}

					.tabcontent li {
						display: block;
						margin-bottom: 15px;
						line-height: 25px;
						margin-top: 15px;
					}

					.tabcontent li i {
						margin-right: 7px;
					}

					.tabcontent h3 {
						margin: 45px 0 25px;
					}

					/* Change background color of buttons on hover */
					.tab button:hover {
						background-color: #EF454D;
					}

					.tabcontent h3 {
						margin: 32px 0 15px;
						font-size: 23px;
					}

					/* Create an active/current tablink class */
					.tab button.active {
						background-color: #EF454D;
					}

					/* Style the tab content */
					.tabcontent {
						display: none;
						padding: 30px 15px;
						border: 1px solid #ccc;
						border-top: none;
					}

					.tabcontent a {
						color: #033d75;
					}

					.faqwr li {
						display: block;
						line-height: 40px;
					}

					.tabcontent li {
						font-weight: normal;
						line-height: 27px;
					}

					.fundwr .col-sm-4 label {
						display: block;
						font-weight: bold;
						font-size: 20px;
						margin-top: 25px;
					}

					.fundwr .col-sm-4 select {
						padding: 7px 6px 9px;
						background: #033d75;
						color: #fff;
						border: none;
					}

					.clientlogo li img {
						width: 100px;
					}

					.col-sm-8.clientlogo li {
						display: inline-block;
						margin-right: 20px;
					}

					.col-sm-8.clientlogo {
						padding: 0 0 0 75px;
					}

					.submitbtn {
						background-color: #EF454D !important;
						color: #fff !important;
						border: none !important;
						padding: 12px 30px !important;
						display: inline-block;
						margin-top: 35px;
						font-size: 16px !important;
					}

					.accordion {
						background-color: #033d75;
						color: #fff;
						cursor: pointer;
						padding: 18px;
						width: 100%;
						border: none;
						text-align: left;
						outline: none;
						font-size: 16px;
						transition: 0.4s;
						margin-bottom: 2px;
						font-weight: bold;
					}

					.inner-card-wr.accordianwr {
						margin-bottom: 45px;
					}

					.accordion.active,
					.accordion:hover {
						background-color: #EF454D;
						outline: none;
						border: none;
					}

					.accordion:after {
						content: '\002B';
						color: #fff;
						font-weight: bold;
						float: right;
						margin-left: 5px;
					}

					.accordion.active:after {
						content: "\2212";
					}

					.panel {
						padding: 0 18px;
						background-color: white;
						max-height: 0;
						overflow: hidden;
						transition: max-height 0.2s ease-out;
					}

					.inner-card-wr.accordianwr .col-sm-8 h3 {
						margin: 5px 0 15px 0;
					}

					.inner-card-wr.accordianwr .row {
						padding: 0;
						margin: 15px 0 0;
					}

					.inner-card-wr.accordianwr .panel {
						padding: 0;
						margin: 0;
					}

					.panel .inner-card-wr {
						padding: 20px;
					}
				</style>

				<div class="tab">
					<button class="tablinks" onclick="openCity(event, 'London1')" id="defaultOpen">Overview</button>
					<button class="tablinks" onclick="openCity(event, 'Paris1')">How to apply</button>
				</div>
				<div id="London1" class="tabcontent">
					<div class="container">
						<div class="card-single-wr" style="border-top: none; padding-top: 15px;">
							<h2>Research, buy, and track investments funds via our Global Investment Centre</h2>
							<p>Our Global Investment Centre is our investments service through which you can open and invest in a Funds portfolio and ISA Funds portfolio, giving you access to investment funds from StandardRobin and a wide range of other providers.</p>
						</div>
						<div class="inner-card-wr">
							<h2>Why use Global Investment Centre to buy and track your investments?</h2>
							<ul>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Choose from an extensive range of funds</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Invest in a tax-efficient way through an ISA funds portfolio</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Choose to buy, sell or switch funds either online or by phone</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Access GIC via your Personal Internet Banking and manage all your accounts in one convenient place</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Start investing with $100 into each class of funds shares you choose</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">0% initial charge*</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Value your investment in real time, and track its performance online</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">0.39% Account Fee when investing in clean share class funds</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">It’s quick and easy to apply</span></li>
							</ul>
							<a style="margin-top: 15px;" class="toggleclass collapsed" href="#" data-toggle="collapse" data-target="#demo" aria-expanded="false">Are you eligible?</a>
							<div id="demo" class="collapse" style="">
								<p>You can apply for Global Investment Centre if you:</p>
								<ul>
									<li><i class="fa fa-check" aria-hidden="true"></i>are aged 18 or over</li>
									<li><i class="fa fa-check" aria-hidden="true"></i>are a United States resident with a permanent US residential address</li>
									<li><i class="fa fa-check" aria-hidden="true"></i>have an StandardRobin current and/or savings account</li>
								</ul>
								<p>You cannot apply for a Funds Portfolio and ISA Funds Portfolio if you're a non-United States resident (including if you are a United States Crown Servant working overseas).</p>
								<p>Accounts cannot be held in joint names and non-personal accounts are not permitted.</p>
								<p>If you would like to invest with another person, or to make regular contributions rather than investing a lump sum, please call 160000000 to discuss your options.</p>
							</div>
						</div>
						<div class="row" style="padding: 20px 0; border-top: 1px solid #CCC;">
							<div class="col-sm-12">
								<div class="productImportantInfo">
									<p>Global Investment Centre has been created for individual investors who want to make lump sum investments themselves. You cannot make regular payments or joint applications in to the Global Investment Centre.</p>
									<p>Investors should regularly review the funds they've chosen. That's why with Global Investment Centre you can see the current value of your investments, and track their performance, at a glance.</p>
									<p>Once you've applied for the Global Investment Centre, you can open a Funds Portfolio in which to buy, sell and hold your investments. </p>
									<p>You can also apply for an ISA Funds Portfolio so you can hold your investments within a tax-efficient ISA.</p>
									<p>The minimum initial investment is $100 for each class of fund shares for each portfolio. The minimum additional investment is also $100. </p>
									<p>Online trades through the Global Investment Centre are limited to $99,999. If you would like to place a trade of $100,000 or more, you may do so by phone – please call us on <span style="color: red;" class="phone">160000000**.</span></p>
								</div>
							</div>
						</div>
						<div class="card-single-wr fundwr">
							<h2>Find the fund that’s right for you</h2>
							<p>Click on a fund provider or tell us what kind of fund you’re looking for and we’ll help you find the fund that fits your criteria:</p>
							<div class="row">
								<div class="col-sm-4">
									<form>
										<label>Fund type</label>
										<select>
											<option>All fund types</option>
											<option>Accumulation</option>
											<option>Income</option>
										</select>
										<label>Sector</label>
										<select>
											<option>All sectors</option>
											<option>Asia Pacific Excluding Japan</option>
											<option>Asia Pacific Including Japan</option>
											<option>China</option>
											<option>Corporate Bond</option>
											<option>Ethical</option>
											<option>European Smaller Companies</option>
											<option>Europe Excluding UK</option>
											<option>Europe Including UK</option>
											<option>Flexible Investment</option>
											<option>GBP Corporate Bond</option>
											<option>GBP High Yield</option>
											<option>GBP Strategic Bond</option>
											<option>Global</option>
											<option>Global Bonds</option>
											<option>Global Emerging Markets</option>
											<option>Global Emerging Markets Bond</option>
											<option>Global Equity Income</option>
											<option>Japan</option>
											<option>Japanese Smaller Companies</option>
											<option>Mixed Investment 0-35% Shares</option>
											<option>Mixed Investment 20-60% Shares</option>
											<option>Mixed Investment 40-85% Shares</option>
											<option>Money Market</option>
											<option>Multi-asset</option>
											<option>North America</option>
											<option>North American Smaller Companies</option>
											<option>Property</option>
											<option>Specialist</option>
											<option>Targeted Absolute Return</option>
											<option>Technology and Telecommunications</option>
											<option>US All Companies</option>
											<option>US Equity and Bond Income</option>
											<option>US Equity Income</option>
											<option>US Gilts</option>
											<option>US Index Linked Gilts</option>
											<option>US Smaller Companies</option>
											<option>Unclassified Sector</option>
										</select>
										<label>Provider</label>
										<select>
											<option>All providers</option>
											<option>Aberdeen Fund Managers Limited</option>
											<option>Allianz Global Investors GmBH</option>
											<option>Artemis Fund Managers Limited</option>
											<option>Aviva Investors US Fund Services Limited</option>
											<option>Baillie Gifford & Co Limited</option>
											<option>BlackRock Fund Managers Limited</option>
											<option>BNY Mellon Fund Managers Limited (Newton)</option>
											<option>FIL Investment Services (UK) Limited (Fidelity)</option>
											<option>First State Investments (UK) Limited</option>
											<option>StandardRobin Global Asset Management (UK) Ltd</option>
											<option>Invesco Fund Managers Limited</option>
											<option>Investec Fund Managers Limited</option>
											<option>Janus Henderson Investment Funds Limited</option>
											<option>JPMorgan Funds Limited</option>
											<option>Jupiter Unit Trust Managers Limited</option>
											<option>Legal & General (Unit Trust Managers) Limited</option>
											<option>M&G Securities Limited</option>
											<option>Neptune Investment Management Limited</option>
											<option>Sarasin Investment Funds Limited</option>
											<option>Schroder Unit Trusts Limited</option>
											<option>Standard Life Investment Limited</option>
											<option>Threadneedle Investment Services Limited</option>
										</select>
										<input type="submit" value="Search" class="submitbtn">
									</form>
								</div>
								<div class="col-sm-8 clientlogo">
									<ul>
										<li><a href="#"><img src="images\134x64-aberdeen.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-allianz.gif" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-artemis.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-aviva.gif" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-baillie-gifford.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-blackrock.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-bnymellon.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-threadneedle.gif" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-fidelity.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-firststate.jpg" alt=""></a></li>

										<li><a href="#"><img src="logo.png" height="54" wStanRobh="134" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-invesco.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-investec.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-henderson.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-jpmorgan.jpg" alt=""></a></li>

										<li><a href="#"><img src="images\134x64-jupiter.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-LegalGeneral.png" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-mginvestments.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-neptune.gif" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-sarasin.gif" alt=""></a></li>

										<li><a href="#"><img src="images\134x64-schroders.jpg" alt=""></a></li>
										<li><a href="#"><img src="images\134x64-sli.png" alt=""></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>

					<div class="card-detail-wr">
						<div class="container">
							<div class="card-single-wr">
								<h2>Things to bear in mind</h2>
								<div class="inner-card-wr">
									<h3>It is important to remember</h3>
									<ul>
										<li><i class="fa fa-check" aria-hidden="true"></i> You need to have an StandardRobin current or savings account to buy funds via our Global Investment Centre.</li>
										<li><i class="fa fa-check" aria-hidden="true"></i> The Global Investment Centre is offered without advice, on an execution only basis. StandardRobin is not required to assess the suitability of this service for you, which means that the protection offered by the Financial Conduct Authority's rules on assessing suitability will not apply. If you have any doubts about whether this service is suitable for your needs, you should seek advice from a Financial Adviser (you may be charged for any advice you receive)</li>
										<li><i class="fa fa-check" aria-hidden="true"></i> Investments should be considered as a medium to long-term commitment. This means you should be prepared to hold them for at least five years.</li>
										<li><i class="fa fa-check" aria-hidden="true"></i> Investing through our Global Investment Centre involves taking some investment risk. The value of investments can go down as well as up and you may get back less than you invested. For some investments this can also happen as a result of exchange rate fluctuations as shares and funds may have an exposure to overseas markets.</li>
										<li><i class="fa fa-check" aria-hidden="true"></i> You should carefully consider the specific risks of investing in emerging market securities.</li>
										<li><i class="fa fa-check" aria-hidden="true"></i> The value of any tax benefits described depends on your individual circumstances. Tax rules may change in the future.</li>
										<li><i class="fa fa-check" aria-hidden="true"></i>Additional risks may apply, please refer to our <a target="_blank" href="#" title="Key Features of Funds Portfolio and ISA Funds Portfolio PDF, link opens in a new window">Key Features of Funds Portfolio and ISA Funds Portfolio document</a> for further information.</li>
									</ul>
									<h3>Apply online (via Personal Internet Banking)</h3>
									<p>Please read and save the following documents before applying for Global Investment Centre:</p>
									<ul>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Global Investment Centre Terms and Conditions</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Key Features of Funds Portfolio and ISA Funds Portfolio</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">US FSCS Information Sheet and Exclusions List</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Eligibility requirements</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Privacy Notice</a></li>
									</ul>
									<p>To read our PDF files you'll need Acrobat Reader 4.0 or above. Visit <a href="#">Adobe UK</a>.</p>
									<p>If you're using screen reading technology that cannot read PDFs, a converter is available at <a href="#">Access Adobe</a>.</p>
									<a href="#" class="bussiness-btn-larg" style="color: #fff;">Apply online</a>
									<p style="margin-top: 20px;">More information on the application process is available on the ‘How to apply’ page.</p>
								</div>
							</div>
						</div>
					</div>
					<div class="card-detail-wr">
						<div class="container">
							<div class="card-single-wr">
								<h2>More details/FAQs</h2>
								<div class="inner-card-wr">
									<button class="accordion">How it works</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>Once you've registered for the Global Investment Centre, you can open a Funds Portfolio in which to buy, sell and hold your investments.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>You can also apply for an ISA Funds Portfolio so you can hold your investments within a tax-efficient ISA.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>There are no new passwords to remember because you access your Global Investment Centre through Internet Banking. Simply log on and select 'Investments'.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>You can see the current value of your investment and track its performance online.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>Interactive research tools help you make informed decisions about what to invest in and when.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>Anyone with an StandardRobin current or savings account can register for our Global Investment Centre.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>Global Investment Centre integrates seamlessly with your nominated StandardRobin account as the money for your purchases and the proceeds from your sales will be taken from and paid into that account.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>You can choose to buy, sell or switch funds either online or by phone. Please note that purchases or sales you make from 4pm onwards on a business day will be processed the following business day. The minimum initial investment is $100 for each class of fund shares for each portfolio. The minimum additional investment is also $100.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>Please note online trades through the Global Investment Centre are limited to $99,999. If you would like to place a trade of $100,000 or more, please call us on 160000000**.</li>
										</ul>
									</div>

									<button class="accordion">How much does it cost?</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>There is no charge for setting up the Global Investment Centre service.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>An Account Fee of 0.39% per annum applies when investing in clean share class funds.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>There is no initial charge on any funds in the Global Investment Centre.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>An annual management charge and other expenses will apply.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>In the past fund managers, including StandardRobin, have used several different methods to illustrate charges. To make these charges clearer and comparisons simpler for you, we’re moving to the Ongoing Charges Figure (OCF), which is being adopted throughout the investment fund industry. The OCF incorporates the Annual Management Charge (AMC) as well as any other additional charges from the fund provider.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>Full details of the annual management charge and any other expenses (including the Account Fee) are available in the <a target="_blank" href="#" title="Key Features of Funds Portfolio and ISA Funds Portfolio PDF, link opens in new window">Key Features of Funds Portfolio and ISA Funds Portfolio Document</a>. Specific fund charges are available in the relevant Key Investor Information Documents for each fund.</li>
										</ul>
									</div>

									<button class="accordion">What types of funds can I hold?</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>There is a wide range of open ended investment company (OEIC) and unit trust clean share class funds that you can hold within each of your account(s).</li>
										</ul>
									</div>

									<button class="accordion">What are the charges?</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>An Account Fee of 0.39% per annum applies when investing in clean share class funds. There is no initial charge on any funds in the Global Investment Centre; however an annual management charge and other expenses will apply.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>The Account Fee will be charged as an annual percentage rate and calculated using the value of any holdings in <a href="#" title="clean share classes">clean share classes </a>within your account. The annual percentage rate for the Account Fee will be 0.39% per annum. The charge will be taken on a monthly basis from your default settlement account for your Funds Portfolio in arrears. The Account Fee will be payable by you for the services we provide when arranging the sale and purchase of fund shares in clean share classes as well as custody and administration of those fund shares when they are held in your account.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>Full details of charges, including annual management charges and any other expenses are available in the <a href="#" title="Key Features Document">Key Features Document</a> and the individual Fund Details.</li>
										</ul>
									</div>

									<button class="accordion">Is there a minimum amount that I have to invest?</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>The minimum initial investment is $100 for each class of fund shares for each portfolio. The minimum additional investment is also $100.</li>
										</ul>
									</div>

									<button class="accordion">What happens after I have placed a buy instruction?</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>If a Buy instruction is placed prior to the dealing deadline (for individual dealing deadlines please see the Fund Details Document for the specific fund) then your order will normally be placed with the fund provider before the fund's next valuation point. The valuation point for each fund is shown in the Fund Details.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>You can then view the status of an instruction by clicking on 'Details' located within the 'My order status' section. Once we receive confirmation that the instruction has been executed by the fund provider, your new holding will be reflected within 'My fund portfolio' section. When you place a Buy instruction a hold will be placed on the required monies in your chosen settlement account or in the case of your ISA this will be the Uninvested cash account. The money will be taken from your settlement account or your Uninvested cash account on settlement day.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>We will send you a confirmation of the number of fund shares purchased for you and the price you paid.</li>
										</ul>
									</div>

									<button class="accordion">Can I make regular contributions to a fund or make a joint application?</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>No. We don't currently offer this service for Global Investment Centre. However, you may invest as often as you like subject to the minimum investment amount of $100 for each fund for each account.</li>
										</ul>
									</div>
									<button class="accordion">What is the Costs and Charges Disclosure Document?</button>
									<div class="panel">
										<ul>
											<li><i class="fa fa-check" aria-hidden="true"></i>From 3 January 2018, a key piece of European legislation called MiFID II will apply to financial services that are regulated in the UK. Part of the MiFID II legislation requires us to provide you with the most recent version of a 'Costs and Charges Disclosure Document' before you make any investment.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>When you telephone or place a deal on-line you will be asked to confirm that you have read the appropriate Costs and Charges Disclosure Document before we can proceed with your investment instruction.</li>
											<li><i class="fa fa-check" aria-hidden="true"></i>The Costs and Charges Disclosure Document provides you with a generic example of the costs and charges associated with your Account (both the product, service and ancillary costs) in a percentage and monetary amount. There is also an illustration of the potential cumulative effect of costs on the return of your investment over time. </li>
											<li><i class="fa fa-check" aria-hidden="true"></i>Please note the illustrations in each Costs and Charges Disclosure Document are based on assumed growth rates and are not reliable indicators of future performance. Please be aware that you may not get back what you originally invested.</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="card-detail-wr">
						<div class="container">
							<div class="card-single-wr">
								<h2>Investment risk</h2>
								<p>All investments carry some risk. The value of investments (and any income received from them) can fall as well as rise and you may not get back what you invested. For some investments this can also happen as a result of exchange rate fluctuations as shares and funds may have an exposure to overseas markets.</p>

								<h2>Time commitment</h2>
								<p>Most investments should be considered as a medium to long-term commitment, meaning you should be prepared to hold them for at least five years.</p>

								<h2>Tax benefits</h2>
								<p>The value of any tax benefits described depends on your individual circumstances. Tax rules may change in the future.</p>
							</div>
						</div>
					</div>
					<div class="card-detail-wr">
						<div class="container row">
							<div class="col-sm-6">
								<div class="card-single-wr">
									<h2>Need to speak to us?</h2>
									<p><strong>160000000</strong></p>
									<p>Our opening hours are Monday to Friday 8am to 9pm.</p>
									<p>Textphone:160000000.</p>
									<p>To help us continually improve our service, and in the interests of security, we may monitor and/or record your communications with us.</p>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="card-single-wr">
									<h2>Prefer to talk face-to-face?</h2>
									<p>Pop into your nearest branch for a chat.</p>
									<a style="color: #fff;" href="#" class="bussiness-btn-larg">Find a branch</a>
								</div>
							</div>
							<p><strong>The Global Investment Centre is offered without advice, on an execution only basis. StandardRobin is not required to assess the suitability of this service for you, which means that the protection offered by the Financial Conduct Authority’s rules on assessing suitability will not apply. If you have any doubts about whether this service is suitable for your needs, you should seek advice from a Financial Adviser (you may be charged for any advice you receive).</strong></p>
						</div>
					</div>
				</div>
				<div id="Paris1" class="tabcontent">
					<div class="container">
						<div class="card-single-wr" style="border-top: none; padding-top: 15px;">
							<h2>Things you should know before applying</h2>
							<p>In line with anti-money laundering regulations, we need to have a record of your personal identification (ID) before we can open an investment for you.</p>
							<p>To help us process your application as quickly as possible, please call us to confirm if we have a record of your ID. If not, we may ask you to take one of the following forms of ID to your nearest branch:</p>

							<ul>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Current passport</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Current full US driving licence</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">National ID Card</span></li>
								<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Armed Forces Card</span></li>
							</ul>
							<a style="margin-top: 15px;" class="toggleclass collapsed" href="#" data-toggle="collapse" data-target="#demo1" aria-expanded="false">Eligibility criteria</a>
							<div id="demo1" class="collapse" style="">
								<p>You can apply for Global Investment Centre if you:</p>
								<ul>
									<li><i class="fa fa-check" aria-hidden="true"></i>are aged 18 or over</li>
									<li><i class="fa fa-check" aria-hidden="true"></i>are a US resident with a permanent US residential address</li>
									<li><i class="fa fa-check" aria-hidden="true"></i>have an StandardRobin current and/or savings account</li>
								</ul>
								<p>You cannot apply for a Funds Portfolio and ISA Funds Portfolio if you're a non-US resident (including if you are a US Crown Servant working overseas).</p>
								<p>Accounts cannot be held in joint names and non-personal accounts are not permitted.</p>
								<p>If you would like to invest with another person, or to make regular contributions rather than investing a lump sum, please call 160000000* to discuss your options.</p>
							</div>
						</div>
					</div>

					<div class="card-detail-wr">
						<div class="container">
							<div class="card-single-wr">
								<h2>Before you apply</h2>
								<div class="inner-card-wr">
									<p>Before you apply, please read and save the following documents:</p>
									<ul>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Global Investment Centre Terms and Conditions</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Key Features of Funds Portfolio and ISA Funds Portfolio</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">US FSCS Information Sheet and Exclusions List</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Eligibility requirements</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Additional Permitted Subscription (APS) Transfer Authority Application Form</a></li>
										<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">Privacy Notice</a></li>
									</ul>
									<a style="color: #fff;" href="#" class="bussiness-btn-larg">Apply online</a>
								</div>
								<h2 style="margin-top: 35px;">To read our PDF files</h2>
								<div class="inner-card-wr">
									<p>To read our PDF files you'll need to have Acrobat Reader 8.0™ or above installed on your computer. If you don't, it's free and can be downloaded from <a href="#">Adobe UK</a>. If you are accessing this website using reading technology that cannot read PDFs, a converter is available at <a href="#">Access Adobe</a>.</p>
								</div>
							</div>
						</div>
					</div>

					<div class="card-detail-wr">
						<div class="container row">
							<div class="col-sm-6">
								<div class="card-single-wr">
									<h2>Not yet registered for Personal Internet Banking?</h2>
									<p>If you want to keep track of your investment funds online you'll first need to register for Personal Internet Banking.</p>
									<p>Once you have registered for Personal Internet Banking you can then open your Global Investment Centre account online.</p>
									<a style="color: #fff;" href="#" class="bussiness-btn-larg">Register for Personal Investment Banking</a>
									<p style="margin-top: 25px;">Alternatively, call us on 160000000 to apply for StandardRobin Global Investment Centre and buy your chosen fund.</p>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="card-single-wr">
									<h2>Apply by phone</h2>
									<p>You can also choose to apply for Global Investment Centre by phone – although note it will take longer to complete your application as we’ll have to send your documents by post.</p>
									<p><strong>Call us on 160000000*</strong></p>
								</div>
							</div>
							<div class="col-sm-12">
								<p><strong>The Global Investment Centre is offered without advice, on an execution only basis. StandardRobin is not required to assess the suitability of this service for you, which means that the protection offered by the Financial Conduct Authority's rules on assessing suitability will not apply. If you have any doubts about whether this service is suitable for your needs, you should seek advice from a Financial Adviser (you may be charged for any advice you receive).</strong></p>
								<p>Please note online trades through the Global Investment Centre are limited to $99,999. If you would like to place a trade of $100,000 or more, you may do so by phone – please call us on 160000000.</p>
								<p>* Our opening hours are Monday to Friday 8.00am to 6.00pm (excluding StandardRobin Holidays). Textphone: <strong>160000000</strong>.</p>
								<p>To help us continually improve our service, and in the interests of security, we may monitor and/or record your communications with us.</p>
							</div>
						</div>
					</div>
				</div>

				<script>
					function openCity(evt, cityName) {
						var i, tabcontent, tablinks;
						tabcontent = document.getElementsByClassName("tabcontent");
						for (i = 0; i < tabcontent.length; i++) {
							tabcontent[i].style.display = "none";
						}
						tablinks = document.getElementsByClassName("tablinks");
						for (i = 0; i < tablinks.length; i++) {
							tablinks[i].className = tablinks[i].className.replace(" active", "");
						}
						document.getElementById(cityName).style.display = "block";
						evt.currentTarget.className += " active";
					}

					// Get the element with id="defaultOpen" and click on it
					document.getElementById("defaultOpen").click();
				</script>
			</div>
		</div>
	</div>
</div>



<!--content end-->
<div class="col-sm-12 connectus">
	<div class="container">
		<div class="inner-connect">
			<h5> Connect with us </h5>
			<a href="contactandsupport">Listening to what you have to say about our services matters to us.</a>
		</div>
	</div>
</div>
<!-- Start Footer -->
 <!-- Start Footer -->
 <footer class="bussiness-footer-1x">
        <div class="bussiness-footer-content ">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <h5> Help & support </h5>
                        <a href="contactandsupport">Got a question? We are here to help you </a>
                    </div>
                    <div class="col-md-3">
                        <h5> Find a branch </h5>
                        <a href="ways-we-can-help">Find your nearest StanRob Banking location</a>
                    </div>
                    <div class="col-md-3">
                        <h5> Our performance </h5>
                        <a href="investing">View our service dashboard to see how we're doing</a>
                    </div>

                    <div class="col-md-3">
                        <h5> About StanRob </h5>
                        <a href="news">Careers, media, investor and corporate information</a>
                    </div>

                    <div class="container">
                        <div class="">
                            <div class="col-md-12 footer-info">
                                <div class="row">
                                    <!-- <p class="text-center">This Credit Union is federally insured by the National Credit Union Administration. We do business in accordance with the Fair Housing Law and Equal opportunity Credit Act.</p> -->

                                    <div class="col-md-3">
                                        <div class="footer-info-left">
                                            <!--<p><a href="#">Industri Banking Group</a></p>-->
                                            <img style="max-width:125px;" src="footerlogo.png" class="d-inline-block align-top" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-center">3211 w division trl #22 Arlington Tx 76012<br>
                                        <strong>Call us : 160000000</strong>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="footer-info-right">
                                            <ul>
                                                <li><a href="#"> <i class="fa fa-facebook"></i> </a></li>
                                                <li><a href="#"> <i class="fa fa-twitter"></i> </a></li>
                                                <li><a href="#"> <i class="fa fa-google"></i> </a></li>
                                                <li><a href="#" target="_blank"> <i class="fa fa-linkedin"></i> </a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-center text-muted">© 2025 StandardRobin- All rights reserved.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer --> <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js\bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Wow Script -->
<script src="js\wow.min.js"></script>
<!-- Counter Script -->
<script src="js\waypoints.min.js"></script>
<script src="js\jquery.counterup.min.js"></script>
<!-- Masonry Portfolio Script -->
<script src="js\jquery.filterizr.min.js"></script>
<script src="js\filterizer-controls.js"></script>
<!-- OWL Carousel js-->
<script src="js\owl.carousel.min.js"></script>
<!-- Lightbox js -->
<script src="inc\lightbox\js\jquery.fancybox.pack.js"></script>
<script src="inc\lightbox\js\lightbox.js"></script>
<!-- Google map js -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCa6w23do1qZsmF1Xo3atuFzzMYadTuTu0"></script>
<script src="js\map.js"></script>
<!-- loader js-->
<script src="js\fakeLoader.min.js"></script>
<!-- Scroll bottom to top -->
<script src="js\scrolltopcontrol.js"></script>
<!-- menu -->
<script src="js\bootstrap-4-navbar.js"></script>
<!-- Stiky menu -->
<script src="js\jquery.sticky.js"></script>
<!-- youtube popup video -->
<script src="js\jquery.magnific-popup.min.js"></script>
<!-- Color switcher js -->
<script src="js\color-switcher.js"></script>
<!-- Color-switcher-active -->
<script src="js\color-switcher-active.js"></script>
<!-- Custom script -->
<script src="js\custom.js"></script>
<script src="js\jquery.bxslider.min.js"></script>
<script src="js/toastr.js"></script>
<script src="js/sweetalert.js"></script>



<script type="text/javascript">
	$(document).ready(function() {
		if (($(window).width() > 769)) {
			$('.bxsliderwr').bxSlider({
				minSlides: 5,
				maxSlides: 5,
				slidewidth: 230,
				pager: true,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		} else if (($(window).width() < 769) && ($(window).width() > 481)) {
			$('.bxsliderwr').bxSlider({
				minSlides: 3,
				maxSlides: 3,
				slidewidth: 230,
				pager: true,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		} else {
			$('.bxsliderwr').bxSlider({
				minSlides: 3,
				maxSlides: 3,
				slidewidth: 230,
				pager: false,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		}
	});
</script>

<script type="text/javascript">
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].addEventListener("click", function() {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.maxHeight) {
				panel.style.maxHeight = null;
			} else {
				panel.style.maxHeight = panel.scrollHeight + "px";
			}
		});
	}
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
	var Tawk_API = Tawk_API || {},
		Tawk_LoadStart = new Date();
	(function() {
		var s1 = document.createElement("script"),
			s0 = document.getElementsByTagName("script")[0];
		s1.async = true;
		s1.src = 'https://embed.tawk.to/';
		s1.charset = 'UTF-8';
		s1.setAttribute('crossorigin', '*');
		s0.parentNode.insertBefore(s1, s0);
	})();
</script>
<!--End of Tawk.to Script-->


</body>

</html>