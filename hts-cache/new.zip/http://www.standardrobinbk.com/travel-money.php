﻿<!doctype html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8">

<head>
	<title>Travel Money | StandardRobin</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<!-- Favicon icon -->
	<link rel="stylesheet" href="site.min.css" type="text/css">
	<link rel="shortcut icon" type="image/png" href="images\favicon.png">
	<!-- Google fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,400,400i,500,500i,700" rel="stylesheet">
	<!-- Bootstrap -->
	<link href="css\bootstrap.min.css" rel="stylesheet">
	<!-- Fontawsome -->
	<link href="css\font-awesome.min.css" rel="stylesheet">
	<!-- Animate CSS-->
	<link href="css\animate.css" rel="stylesheet">
	<!-- menu CSS-->
	<link href="css\bootstrap-4-navbar.css" rel="stylesheet">
	<!-- Portfolio Gallery -->
	<link href="css\filterizer.css" rel="stylesheet">
	<!-- Lightbox Gallery -->
	<link href="inc\lightbox\css\jquery.fancybox.css" rel="stylesheet">
	<!-- OWL Carousel -->
	<link rel="stylesheet" href="css\owl.carousel.min.css">
	<link rel="stylesheet" href="css\owl.theme.default.min.css">
	<!-- Preloader CSS-->
	<link href="css\fakeLoader.css" rel="stylesheet">
	<!-- Main CSS -->
	<link rel="stylesheet" type="text/css" href="css/sweetalert.css">
	<link href="style.css" rel="stylesheet">
	<!-- Default CSS Color -->
	<link href="color\default.css" rel="stylesheet">
	<!-- Color CSS -->
	<link rel="stylesheet" href="color/color-switcher.css">
	<!-- Default CSS Color -->
	<link href="color\default.css" rel="stylesheet">
	<!-- Color CSS -->
	<link rel="stylesheet" href="color\color-switcher.css">
	<!-- Responsive CSS -->
	<link href="css\responsive.css" rel="stylesheet">
	<link href="css\customcss.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/toastr.css">

</head>
<!--header open in header-->


<body>
    <style>
        .navbar-brand h2 {
            font-size: 35px;
            margin-top: 2px;
        }
    </style>
    <!-- Preloader -->
	<div id="fakeloader"></div>

<div class="top-menu-1x">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="top-menu-left">
                    <p>Need help? Contact Us</p>

                    <b><i class="fa fa-envelope"></i><a style="color:#fff;" href="mailto:"></a></b>
                </div>
            </div>
            <div class="col-md-6">
                <div class="top-menu-right">
                    <div class="footer-info-right">
                        <ul>
                            <a href="secure/customer_login" style="background-color:white; color:black; border: 2px red; padding:2px;"><i class="fa fa-lock"></i> sign in</a>
                            <li><a href="#"> <i class="fa fa-twitter"></i> </a></li>
                            <li><a href="#"> <i class="fa fa-google"></i> </a></li>
                            <li><a href="#"> <i class="fa fa-linkedin"></i> </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

   
    <div class="bussiness-main-menu-1x">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="business-main-menu">
						<nav class="navbar navbar-expand-lg navbar-light bg-light btco-hover-menu">
							<a class="navbar-brand" href="/">
								<img style="max-width:125px;" src="logo.png" class="d-inline-block align-top" alt="">
								<!--<h2><span style="color:#EC4550;">I</span><span style="color:#0E3768;">BG</span></h2>-->
							</a>
							<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
								<span class="navbar-toggler-icon"></span>
							</button>

							<div class="collapse navbar-collapse" id="navbarSupportedContent">

								<ul class="navbar-nav ml-auto business-nav">
									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Banking Services <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Accounts & services</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav1">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="current-accounts.php" class="menuhead">Current Accounts</a>
																				<li><a class="dropdown-item" href="premier-accounts.php">StanRob Account</a></li>
																				<li><a class="dropdown-item" href="advance-accounts.php">Advance Account</a></li>
																				<li><a class="dropdown-item" href="student-accounts.php">Student Account</a></li>
																				<li><a class="dropdown-item" href="bank-accounts.php">Bank Account</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="saving-accounts.php" class="menuhead">Savings</a>
																				<li><a class="dropdown-item" href="isas-accounts.php">ISAs</a></li>
																				<li><a class="dropdown-item" href="online-bonus-saver.php">Online Bonus Saver</a></li>
																				<li><a class="dropdown-item" href="flexible-saver.php">Flexible Saver</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="../credit-cards" class="menuhead">Credit cards</a>
																				<li><a class="dropdown-item" href="32-month-balance-transfer">32 Month Transfer Credit Card</a></li>
																				<li><a class="dropdown-item" href="advance.php">Advance Credit Card</a></li>
																				<li><a class="dropdown-item" href="dual.php">Dual Credit Card</a></li>
																				<li><a class="dropdown-item" href="classic.php">Classic Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier.php">StanRob Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier-world-elite.php">StanRob World Elite Mastercard</a></li>
																				<li><a class="dropdown-item" href="student.php">Student Credit Card</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Services</a>
																				<li><a class="dropdown-item" href="ways-to-bank.php">Ways to bank</a></li>
																				<li><a class="dropdown-item" href="phone-banking.php">Voice ID</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">Contact & Support</a></li>
																				<li><a class="dropdown-item" href="branch-locator.php">Find a Branch</a></li>
																				<a style="margin-top: 15px;" href="international.php" class="menuhead">International services</a>
																				<li><a class="dropdown-item" href="currency-account.php">Currency Account</a></li>
																				<li><a class="dropdown-item" href="money-transfer.php">International Payments</a></li>
																				<li><a class="dropdown-item" href="travel-money.php">Travel money</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>
									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Borrowing <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Loans & mortgages</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav2">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="loans" class="menuhead">Loans</a>
																				<li><a class="dropdown-item" href="personal-loans.php">Personal Loan</a></li>
																				<li><a class="dropdown-item" href="car-loans.php">Car Loan</a></li>
																				<li><a class="dropdown-item" href="flexible.php">Flexiloan</a></li>
																				<li><a class="dropdown-item" href="premier-personal.php">StanRob Personal Loan</a></li>
																				<li><a class="dropdown-item" href="graduate-loans.php">Graduate Loan</a></li>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="overdrafts" class="menuhead">Overdrafts</a>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="mortgages" class="menuhead">Mortgages</a>
																				<li><a class="dropdown-item" href="first-time-buyers.php">First time buyer</a></li>
																				<li><a class="dropdown-item" href="95-mortgages.php">95% Mortgages</a></li>
																				<li><a class="dropdown-item" href="remortgage.php">Remortgage</a></li>
																				<li><a class="dropdown-item" href="buy-to-let-mortgages.php">Buy to let</a></li>
																				<li><a class="dropdown-item" href="existing-customers.php">Existing homeowner</a></li>
																				<li><a class="dropdown-item" href="mortgage-rates.php">Mortgage rates</a></li>
																				<li><a class="dropdown-item" href="armed-forces.php">Armed Forces Personnel</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="../credit-cards" class="menuhead">Credit cards</a>
																				<li><a class="dropdown-item" href="32-month-balance-transfer.php">32 Month Transfer Credit Card</a></li>
																				<li><a class="dropdown-item" href="advance.php">Advance Credit Card</a></li>
																				<li><a class="dropdown-item" href="dual.php">Dual Credit Card</a></li>
																				<li><a class="dropdown-item" href="classic.php">Classic Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier.php">StanRob Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier-world-elite.php">StanRob World Elite Mastercard</a></li>
																				<li><a class="dropdown-item" href="student.php">Student Credit Card</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Services</a>
																				<li><a class="dropdown-item" href="contactandsupport.php">Help & Support</a></li>
																				<li><a class="dropdown-item" href="money-worries.php">Money Worries</a></li>
																				<li><a class="dropdown-item" href="branch-locator.php">Find a Branch</a></li>

																				<a style="margin-top: 15px;" href="tools-and-guides.php" class="menuhead">Tools & Guides</a>
																				<li><a class="dropdown-item" href="overpayment-calculator.php">Overpayment calculator</a></li>
																				<li><a class="dropdown-item" href="repayment-calculator.php">Repayment calculator</a></li>
																				<li><a class="dropdown-item" href="bank-of-england-base-rate.php">Base rate information</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Investing <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Products & analysis</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav3">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="investing" class="menuhead">Investments</a>
																				<li><a class="dropdown-item" href="investment-funds.php">Investment funds</a></li>
																				<li><a class="dropdown-item" href="world-selection-isa.php">World Selection ISA</a></li>
																				<li><a class="dropdown-item" href="sharedealing.php">Sharedealing</a></li>
																				<li><a class="dropdown-item" href="premier-financial-advice.php">StanRob Financial Advice</a></li>
																				<li><a class="dropdown-item" href="stand-alone-investment-advice.php">Stand-alone Investment Advice</a></li>
																				<li><a class="dropdown-item" href="onshore-investment-bond.php">Onshore Investment Bond</a></li>
																				<li><a class="dropdown-item" href="child-trust-funds.php">Child Trust fund</a></li>
																				<li><a class="dropdown-item" href="investing.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="news.php" class="menuhead">Financial news & analysis</a>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="why-invest-with-us.php" class="menuhead">Why invest with us?</a>
																				<li><a class="dropdown-item" href="why-invest-with-u.phps">Find out more</a></li>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="wealth-insights.php" class="menuhead">Wealth Insights </a>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="investment-funds-online.php" class="menuhead">Global Investment Centre</a>
																				<li><a class="dropdown-item" href="investment-funds-online.php">Find out more</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport" class="menuhead">Customer support</a>
																				<li><a class="dropdown-item" href="gsa.php">Log on to Global Investment<br>Centre</a></li>
																				<li><a class="dropdown-item" href="gsa.php">Log on to Sharedealing</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">Investments contacts</a></li>
																				<li><a class="dropdown-item" href="selected-investment-funds.php">Existing Selected Investments<br>Customers</a></li>
																				<li><a class="dropdown-item" href="getting-started.php">Getting started with investing</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Insurance <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Property & family</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav4">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="insurance.php" class="menuhead">Insurance</a>
																				<li><a class="dropdown-item" href="home-insurance.php">Home Insurance</a></li>
																				<li><a class="dropdown-item" href="travel-insurance.php">Travel Insurance</a></li>
																				<li><a class="dropdown-item" href="student-insurance.php">Student Insurance</a></li>
																				<li><a class="dropdown-item" href="insurance.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="life-insurance.php" class="menuhead">Life Insurance</a>
																				<li><a class="dropdown-item" href="life-cover.php">Life Cover</a></li>
																				<li><a class="dropdown-item" href="critical-illness-cover.php">Critical Illness Cover</a></li>
																				<li><a class="dropdown-item" href="income-cover.php">Income Cover</a></li>
																				<li><a class="dropdown-item" href="protection-telephone-advice.php">Telephone Protection Advice</a></li>
																				<li><a class="dropdown-item" href="life-insurance.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="insurance.php" class="menuhead">Insurance Claims</a>
																				<li><a class="dropdown-item" href="home-insurance-claims.php">Home Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="travel-insurance.php">Travel Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="car-insurance-claims.php">Car Insurance Claims</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="premier-accounts.php" class="menuhead">StanRob Customers</a>
																				<li><a class="dropdown-item" href="premier-travel.php">Travel Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="premier-car.php">Car Insurance Claims</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Life events <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Help & support</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav5">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="life-events.php" class="menuhead">Life events</a>
																				<li><a class="dropdown-item" href="dealing-with-bereavement.php">Bereavement support</a></li>
																				<li><a class="dropdown-item" href="dealing-with-separation.php">Separation support</a></li>
																				<li><a class="dropdown-item" href="settling-in-the-uk.php">Settling in the UK</a></li>
																				<li><a class="dropdown-item" href="getting-married.php">Getting married</a></li>
																				<li><a class="dropdown-item" href="planning-your-retirement.php">Planning your retirement</a></li>
																				<li><a class="dropdown-item" href="growing-your-wealth.php">Growing your wealth</a></li>
																				<li><a class="dropdown-item" href="moving-abroad.php">Moving abroad</a></li>
																				<li><a class="dropdown-item" href="life-events.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="planningtools.php" class="menuhead">Planning tools</a>
																				<li><a class="dropdown-item" href="financial-health-check.php">Financial health check</a></li>
																				<li><a class="dropdown-item" href="planningtools.php">View All</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="protecting-what-matters.php" class="menuhead">Protecting what matters</a>
																				<li><a class="dropdown-item" href="protecting-what-matters.php">Learn more</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Customer support</a>
																				<li><a class="dropdown-item" href="ways-we-can-help.php">Ways we can help</a></li>
																				<li><a class="dropdown-item" href="money-worries.php">Money Worries</a></li>
																				<li><a class="dropdown-item" href="ways-we-can-help.php">Frequently asked questions</a></li>
																				<a style="margin-top: 15px;" href="quality-conversations.php" class="menuhead">Individual Review</a>
																				<li><a class="dropdown-item" href="quality-conversations.php">Book your review today for a<br>quick financial checkup</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

								</ul>
							</div>
						</nav>
					</div>
				</div>
			</div>
		</div> 
	</div>
	<!--NAVIGATION END--> <!-- content start-->
	
    <style>
        #userpinid,
        #useridtextid {
            color: #717171;
            font-size: 1em;
            line-height: 1.375em;
            background: none;
            border: none;
            border-bottom-color: currentcolor;
            border-bottom-style: none;
            border-bottom-width: medium;
            border-bottom-color: currentcolor;
            border-bottom-style: none;
            border-bottom-width: medium;
            border-bottom: 1px solid #ccc;
            padding: .313em;
            margin: .188em 0;
        }
    </style><!--NAVIGATION END--><!-- content start-->
<style type="text/css">
	.item.creditbanner {
		position: relative;
	}

	.banner-content {
		position: absolute;
		top: 45%;
		left: 9%;
		background-color: #fff;
		padding: 30px 50px 30px 10px;
		box-shadow: 0 0 23px -5px #000;
	}

	.banner-content h3 {
		color: #033d75;
		font-size: 30px;
		text-transform: uppercase;
		margin-bottom: 15px;
		font-weight: bold;
	}

	.banner-content p {
		color: #333;
		font-size: 20px;
		margin-bottom: 0;
	}

	.cardWr.row {
		box-shadow: 0 0 15px -3px #000;
		margin: 60px 0;
		border-radius: 0;
	}

	.single-bolg.hover01 a:hover .blog-content {
		color: #EF454D;
		transition: all .5s ease 0s;
	}

	.cardWr .col-sm-8 {
		padding: 30px;
	}

	.cardWr .col-sm-4 {
		padding: 40px 30px 30px;
	}

	.cardWr .col-sm-4 {
		background-color: #033d75;
		color: #fff;
	}

	.cardWr .col-sm-4 .col-sm-12 {
		padding: 0;
	}

	.cardWr .col-sm-12 p {
		margin: 8px 0 15px;
		font-size: 18px;
	}

	.cardWr .col-sm-12 h2 {
		font-size: 22px;
		font-weight: bold;
		color: #033d75;
		margin-bottom: 17px;
		margin-top: 15px;
		text-transform: uppercase;
	}

	.inner-card-wr .fa.fa-check {
		margin-right: 10px;
	}

	.cardWr .col-sm-12 ul,
	.inner-card-wr ul {
		padding-left: 0;
	}

	.inner-card-wr li {
		font-weight: bold;
	}

	.inner-card-wr ul p {
		margin-left: 29px;
		margin-bottom: 18px;
	}

	.card-single-wr h2 {
		font-size: 30px;
		position: relative;
		margin-left: 20px;
		margin-bottom: 30px;
		color: #033d75;
	}

	.card-single-wr h2::before {
		position: absolute;
		left: -25px;
		top: 0;
		width: 5px;
		height: 32px;
		background-color: #EF454D;
		content: '';
	}

	.inner-card-wr h3 {
		margin-bottom: 23px;
		font-size: 24px;
		margin-top: 40px;
		font-weight: bold;
		color: #EF454D;
	}

	.cardWr .col-sm-12 li,
	.inner-card-wr li {
		display: block;
		margin-bottom: 14px;
	}

	.card-single-wr {
		border-top: 1px solid #033d75;
		padding: 45px 0 22px;
	}

	.inner-card-wr p a {
		color: #033d75;
		text-decoration: underline;
	}

	.firstspan {
		width: 4%;
		display: inline-block;
		vertical-align: top;
	}

	.secondspan {
		display: inline-block;
		width: 90%;
		vertical-align: top;
	}

	.rightwr .col-sm-12 p {
		font-size: 18px;
		line-height: 27px;
		margin-bottom: 20px;
	}

	p span {
		display: block;
		font-size: 16px;
	}

	.readmoreWr {
		text-align: left;
		margin: 20px 0 20px;
		padding-left: 15px;
	}

	.fa.fa-info-circle {
		margin-right: 10px;
	}

	i.fa.fa-check {
		color: #033d75;
		font-size: 19px;
	}

	.inner-card-wr.lowerwr ul {
		margin: 5px 0;
	}

	i.fa.fa-download {
		margin-right: 10px;
		color: #033d75;
	}

	.inner-card-wr.lowerwr li {
		font-weight: normal;
	}

	.inner-card-wr.lowerwr li a {
		color: #033d75;
	}

	.inner-card-wr.lowerwr li a:hover {
		color: #EF454D;
	}

	.toggleclass {
		color: #333;
		font-size: 18px;
		font-weight: bold;
		text-decoration: underline;
		margin-bottom: 25px;
		display: inline-block;
	}

	.toggleclass:hover {
		text-decoration: underline;
	}

	.logonwr {
		margin-bottom: 35px;
	}

	.collapse h3 a {
		color: #033d75;
	}

	.business-wr {
		padding: 0;
		margin-top: 40px;
	}

	.blog-content {
		font-size: 22px;
		margin: 15px 0;
		text-align: left;
	}

	.single-bolg.hover01 {
		margin-top: 0;
	}

	#demo1 .col-sm-6 h3 {
		margin-top: 0;
	}

	.col-sm-12 li {
		font-weight: bold;
	}

	.accordion {
		background-color: #033d75;
		color: #fff;
		cursor: pointer;
		padding: 18px;
		width: 100%;
		border: none;
		text-align: left;
		outline: none;
		font-size: 16px;
		transition: 0.4s;
		margin-bottom: 2px;
		font-weight: bold;
	}

	.inner-card-wr.accordianwr {
		margin-bottom: 45px;
	}

	.accordion.active,
	.accordion:hover {
		background-color: #EF454D;
		outline: none;
		border: none;
	}

	.accordion:after {
		content: '\002B';
		color: #fff;
		font-weight: bold;
		float: right;
		margin-left: 5px;
	}

	.accordion.active:after {
		content: "\2212";
	}

	.panel {
		padding: 0 18px;
		background-color: white;
		max-height: 0;
		overflow: hidden;
		transition: max-height 0.2s ease-out;
	}

	.inner-card-wr.accordianwr .col-sm-8 h3 {
		margin: 5px 0 15px 0;
	}

	.inner-card-wr.accordianwr .row {
		padding: 0;
		margin: 15px 0 0;
	}

	.inner-card-wr.accordianwr .panel {
		padding: 0;
		margin: 0;
	}

	.panel .inner-card-wr {
		padding: 20px;
	}

	.panel li {
		font-weight: normal;
	}
</style>
<div class="business-main-slider">
	<div class="owl-carousel main-slider">
		<div class="item creditbanner">
			<div class="hvrbox">
				<img src="images\man-beach-hammock.jpg" alt="credit" class="hvrbox-layer_bottom">
			</div>
			<div class="banner-content">
				<div class="innerBanner container">
					<h3>Travel Money</h3>
					<p>Look no further than your own bank for your Travel Money</p>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="card-detail-wr">
	<div class="container">
		<div class="cardWr row">
			<div class="col-sm-8 leftwr">
				<div class="col-sm-12" style="margin-bottom: 15px;">
					<h2>Travel Money made easy</h2>
					<p>At StandardRobin we’ve made ordering your Travel Money quick and easy – order online and choose home delivery or collect in branch.</p>
				</div>
				<div class="col-sm-12">
					<h4 style="margin-top: 25px;margin-bottom: 25px;">Travel money features:</h4>
					<ul>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Competitive rates</span></li>
						<p>You can check our competitive rates online.</p>

						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Quick & easy to order online</span></li>
						<p>Just follow the onscreen instructions and order your Travel Money in minutes.</p>

						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">All major currencies available</span></li>
						<p>We offer a wide range of foreign currencies for your Travel Money needs.</p>

						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Fee free next day delivery</span></li>
						<p>Order online by 2pm and have your money delivered to your home or chosen branch the next working day. Until 10 December 2018 all orders will be delivered fee free. <a href="#">Terms and Conditions apply</a>. Minimum order $100.</p>

						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Buy back service</span></li>
						<p>Take your unused notes back to any StandardRobin branch and we'll buy them back from you. Please ask in branch for our buy back rates as different exchange rates apply for this service.</p>
					</ul>
				</div>
				<div class="readmoreWr col-sm-12">
					<a href="#" class="bussiness-btn-larg">Check rates and order online</a>
				</div>
			</div>
			<div class="col-sm-4 rightwr">
				<p style="font-size: 28px;font-weight: bold;line-height: 32px;">Travel Money</p>
				<div class="col-sm-12 variableper">
					<p>Find out how to order Travel Money online today</p>
					<p>For details on how we will use your personal information, please see our <a href="#">Privacy Notice (PDF)</a>. StandardRobin Travel Money is provided by Travelex Currency Services Ltd. Please read their Privacy Notice shown within the order form</p>
				</div>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>How to order Travel Money</h2>
			<div class="inner-card-wr lowerwr">
				<p>You can order your Travel Money online 24/7*:</p>
				<ul>
					<li>1. Order before 2pm for delivery the next working day</li>
					<li>2. Select delivery to your home or chosen branch</li>
					<li>3. Choose from all major currencies</li>
				</ul>
				<a href="#" class="bussiness-btn-larg">Check rates and order online</a>
				<div class="inner-card-wr" style="margin-top: 30px;">
					<p>For details on how we will use your personal information, please see our Privacy Notice (PDF)Privacy Notice (PDF) Privacy Notice This link will open in a new window. StandardRobin Travel Money is provided by Travelex Currency Services Ltd. Please read their Privacy Notice shown within the order form.</p>
					<p style="font-size: 12px;">*subject to site maintenance and upgrade periods. </p>
					<a class="toggleclass" href="#" data-toggle="collapse" data-target="#demo1">Order by phone or in branch</a>
					<div id="demo1" class="collapse">
						<div class="row">
							<div class="col-sm-6">
								<h3>Order by phone</h3>
								<p>StandardRobin StanRob customers: 160000000 </p>
								<p>All other customers: 160000000 </p>
								<p>Outside the United States: 160000000</p>
								<p style="font-size: 12px;">†Our lines are open 24 hours a day for StandardRobin StanRob and Advance customers. *Our lines are open from 8am to 10pm every day (excluding Christmas Day, Boxing Day and New Year's Day)</p>
							</div>
							<div class="col-sm-6">
								<h3>Order in branch</h3>
								<p>Most of our branches have packs of euros and US dollars ready and waiting (subject to stock levels).</p>
								<p>Alternatively, order online by 2 p.m. and collect at your chosen branch the next day.</p>
								<a href="#" class="bussiness-btn-larg">Find a branch</a>
							</div>
							<div class="col-sm-6" style="margin-top: 20px;">
								<h3><a href="#">Textphone numbers</a></h3>
							</div>
						</div>
					</div>
				</div>
				<div class="card-single-wr">
					<h2>Your travel checklist</h2>
					<div class="inner-card-wr lowerwr">
						<p>Make sure to follow these tips before, during and after you travel:</p>
						<ul>
							<li>1. Contact us to let us know you're travelling and <a href="#">taking your debit / credit card with you</a>, and note down the lost / stolen emergency number just in case</li>
							<li>2. Order your Travel Money online, by phone or in branch</li>
							<li>3. Get travel insurance<sup>1</sup> and take the policy details along with you</li>
							<li>4. When you return, take your unused notes back to your branch and we'll buy them back from you<sup>2</sup></li>
						</ul>
						<p class="A-PAR16R-RW-ALL"><sup style="font-family: &quot;StandardRobin Univers Next Regular&quot;; font-style: normal; font-weight: 400; background-color: transparent;">1</sup><span style="font-family: &quot;StandardRobin Univers Next Regular&quot;; font-size: 0.875rem; font-style: normal; font-weight: 400; background-color: transparent;">Some of our StandardRobin Current Accounts have Travel Insurance, be sure to check before you book any Travel Insurance.</span><br>
						</p>
						<p class="A-PAR14R-RW-ALL"><sup style="font-family: &quot;StandardRobin Univers Next Regular&quot;, Arial, &quot;PingFang SC&quot;, &quot;Microsoft YaHei&quot;, &quot;Lantinghei SC&quot;, &quot;Heiti SC&quot;, simhei, sans-serif; font-variant-ligatures: inherit; font-variant-caps: inherit; background-color: transparent;">2</sup>Please ask in branch for our buy back rates as different exchange rates apply for this service.</p>
					</div>
				</div>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>You might also be interested in</h2>
			<div class="inner-card-wr">
				<div class="business-wr">
					<div class="container">
						<div class="row">
							<div class="col-md-4">
								<div class="single-bolg hover01">
									<a href="#">
										<figure><img src="images\n1.jpg" alt="slide 1" class=""></figure>
										<div class="blog-content">
											Using your card abroad<i style="margin-left: 10px;" class="fa fa-angle-right" aria-hidden="true"></i>
										</div>
									</a>
									<p>As well as your Travel Money, you can also use your StandardRobin Debit Cards and Credit Cards when you're overseas.</p>
									<p>*Fees apply</p>
								</div>
							</div>
							<div class="col-md-4">
								<div class="single-bolg hover01">
									<a href="#">
										<figure><img src="images\n2.jpg" alt="slide 1" class=""></figure>
										<div class="blog-content">
											StandardRobin Currency Account<i style="margin-left: 10px;" class="fa fa-angle-right" aria-hidden="true"></i>
										</div>
									</a>
									<p>Looking for an easy to manage currency holding account? With no monthly account fees, our Currency Account helps put you in control.</p>
								</div>
							</div>
							<div class="col-md-4">
								<div class="single-bolg hover01">
									<a href="#">
										<figure><img src="images\n3.jpg" alt="slide 1" class=""></figure>
										<div class="blog-content">
											International Payments<i style="margin-left: 10px;" class="fa fa-angle-right" aria-hidden="true"></i>
										</div>
									</a>
									<p>Send money quickly and securely using our International Payments service. Fees may apply.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!--content end-->
<div class="col-sm-12 connectus">
	<div class="container">
		<div class="inner-connect">
			<h5> Connect with us </h5>
			<a href="contactandsupport">Listening to what you have to say about our services matters to us.</a>
		</div>
	</div>
</div>
<!-- Start Footer -->
 <!-- Start Footer -->
 <footer class="bussiness-footer-1x">
        <div class="bussiness-footer-content ">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <h5> Help & support </h5>
                        <a href="contactandsupport">Got a question? We are here to help you </a>
                    </div>
                    <div class="col-md-3">
                        <h5> Find a branch </h5>
                        <a href="ways-we-can-help">Find your nearest StanRob Banking location</a>
                    </div>
                    <div class="col-md-3">
                        <h5> Our performance </h5>
                        <a href="investing">View our service dashboard to see how we're doing</a>
                    </div>

                    <div class="col-md-3">
                        <h5> About StanRob </h5>
                        <a href="news">Careers, media, investor and corporate information</a>
                    </div>

                    <div class="container">
                        <div class="">
                            <div class="col-md-12 footer-info">
                                <div class="row">
                                    <!-- <p class="text-center">This Credit Union is federally insured by the National Credit Union Administration. We do business in accordance with the Fair Housing Law and Equal opportunity Credit Act.</p> -->

                                    <div class="col-md-3">
                                        <div class="footer-info-left">
                                            <!--<p><a href="#">Industri Banking Group</a></p>-->
                                            <img style="max-width:125px;" src="footerlogo.png" class="d-inline-block align-top" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-center">3211 w division trl #22 Arlington Tx 76012<br>
                                        <strong>Call us : 160000000</strong>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="footer-info-right">
                                            <ul>
                                                <li><a href="#"> <i class="fa fa-facebook"></i> </a></li>
                                                <li><a href="#"> <i class="fa fa-twitter"></i> </a></li>
                                                <li><a href="#"> <i class="fa fa-google"></i> </a></li>
                                                <li><a href="#" target="_blank"> <i class="fa fa-linkedin"></i> </a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-center text-muted">© 2025 StandardRobin- All rights reserved.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer --> <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js\bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Wow Script -->
<script src="js\wow.min.js"></script>
<!-- Counter Script -->
<script src="js\waypoints.min.js"></script>
<script src="js\jquery.counterup.min.js"></script>
<!-- Masonry Portfolio Script -->
<script src="js\jquery.filterizr.min.js"></script>
<script src="js\filterizer-controls.js"></script>
<!-- OWL Carousel js-->
<script src="js\owl.carousel.min.js"></script>
<!-- Lightbox js -->
<script src="inc\lightbox\js\jquery.fancybox.pack.js"></script>
<script src="inc\lightbox\js\lightbox.js"></script>
<!-- Google map js -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCa6w23do1qZsmF1Xo3atuFzzMYadTuTu0"></script>
<script src="js\map.js"></script>
<!-- loader js-->
<script src="js\fakeLoader.min.js"></script>
<!-- Scroll bottom to top -->
<script src="js\scrolltopcontrol.js"></script>
<!-- menu -->
<script src="js\bootstrap-4-navbar.js"></script>
<!-- Stiky menu -->
<script src="js\jquery.sticky.js"></script>
<!-- youtube popup video -->
<script src="js\jquery.magnific-popup.min.js"></script>
<!-- Color switcher js -->
<script src="js\color-switcher.js"></script>
<!-- Color-switcher-active -->
<script src="js\color-switcher-active.js"></script>
<!-- Custom script -->
<script src="js\custom.js"></script>
<script src="js\jquery.bxslider.min.js"></script>
<script src="js/toastr.js"></script>
<script src="js/sweetalert.js"></script>



<script type="text/javascript">
	$(document).ready(function() {
		if (($(window).width() > 769)) {
			$('.bxsliderwr').bxSlider({
				minSlides: 5,
				maxSlides: 5,
				slidewidth: 230,
				pager: true,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		} else if (($(window).width() < 769) && ($(window).width() > 481)) {
			$('.bxsliderwr').bxSlider({
				minSlides: 3,
				maxSlides: 3,
				slidewidth: 230,
				pager: true,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		} else {
			$('.bxsliderwr').bxSlider({
				minSlides: 3,
				maxSlides: 3,
				slidewidth: 230,
				pager: false,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		}
	});
</script>

<script type="text/javascript">
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].addEventListener("click", function() {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.maxHeight) {
				panel.style.maxHeight = null;
			} else {
				panel.style.maxHeight = panel.scrollHeight + "px";
			}
		});
	}
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
	var Tawk_API = Tawk_API || {},
		Tawk_LoadStart = new Date();
	(function() {
		var s1 = document.createElement("script"),
			s0 = document.getElementsByTagName("script")[0];
		s1.async = true;
		s1.src = 'https://embed.tawk.to/';
		s1.charset = 'UTF-8';
		s1.setAttribute('crossorigin', '*');
		s0.parentNode.insertBefore(s1, s0);
	})();
</script>
<!--End of Tawk.to Script-->


</body>

</html>