﻿<!doctype html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8">

<head>
	<title>Student Insurance | StandardRobin</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<!-- Favicon icon -->
	<link rel="stylesheet" href="site.min.css" type="text/css">
	<link rel="shortcut icon" type="image/png" href="images\favicon.png">
	<!-- Google fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,400,400i,500,500i,700" rel="stylesheet">
	<!-- Bootstrap -->
	<link href="css\bootstrap.min.css" rel="stylesheet">
	<!-- Fontawsome -->
	<link href="css\font-awesome.min.css" rel="stylesheet">
	<!-- Animate CSS-->
	<link href="css\animate.css" rel="stylesheet">
	<!-- menu CSS-->
	<link href="css\bootstrap-4-navbar.css" rel="stylesheet">
	<!-- Portfolio Gallery -->
	<link href="css\filterizer.css" rel="stylesheet">
	<!-- Lightbox Gallery -->
	<link href="inc\lightbox\css\jquery.fancybox.css" rel="stylesheet">
	<!-- OWL Carousel -->
	<link rel="stylesheet" href="css\owl.carousel.min.css">
	<link rel="stylesheet" href="css\owl.theme.default.min.css">
	<!-- Preloader CSS-->
	<link href="css\fakeLoader.css" rel="stylesheet">
	<!-- Main CSS -->
	<link rel="stylesheet" type="text/css" href="css/sweetalert.css">
	<link href="style.css" rel="stylesheet">
	<!-- Default CSS Color -->
	<link href="color\default.css" rel="stylesheet">
	<!-- Color CSS -->
	<link rel="stylesheet" href="color/color-switcher.css">
	<!-- Default CSS Color -->
	<link href="color\default.css" rel="stylesheet">
	<!-- Color CSS -->
	<link rel="stylesheet" href="color\color-switcher.css">
	<!-- Responsive CSS -->
	<link href="css\responsive.css" rel="stylesheet">
	<link href="css\customcss.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/toastr.css">

</head>
<!--header open in header-->


<body>
    <style>
        .navbar-brand h2 {
            font-size: 35px;
            margin-top: 2px;
        }
    </style>
    <!-- Preloader -->
	<div id="fakeloader"></div>

<div class="top-menu-1x">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="top-menu-left">
                    <p>Need help? Contact Us</p>

                    <b><i class="fa fa-envelope"></i><a style="color:#fff;" href="mailto:"></a></b>
                </div>
            </div>
            <div class="col-md-6">
                <div class="top-menu-right">
                    <div class="footer-info-right">
                        <ul>
                            <a href="secure/customer_login" style="background-color:white; color:black; border: 2px red; padding:2px;"><i class="fa fa-lock"></i> sign in</a>
                            <li><a href="#"> <i class="fa fa-twitter"></i> </a></li>
                            <li><a href="#"> <i class="fa fa-google"></i> </a></li>
                            <li><a href="#"> <i class="fa fa-linkedin"></i> </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

   
    <div class="bussiness-main-menu-1x">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="business-main-menu">
						<nav class="navbar navbar-expand-lg navbar-light bg-light btco-hover-menu">
							<a class="navbar-brand" href="/">
								<img style="max-width:125px;" src="logo.png" class="d-inline-block align-top" alt="">
								<!--<h2><span style="color:#EC4550;">I</span><span style="color:#0E3768;">BG</span></h2>-->
							</a>
							<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
								<span class="navbar-toggler-icon"></span>
							</button>

							<div class="collapse navbar-collapse" id="navbarSupportedContent">

								<ul class="navbar-nav ml-auto business-nav">
									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Banking Services <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Accounts & services</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav1">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="current-accounts.php" class="menuhead">Current Accounts</a>
																				<li><a class="dropdown-item" href="premier-accounts.php">StanRob Account</a></li>
																				<li><a class="dropdown-item" href="advance-accounts.php">Advance Account</a></li>
																				<li><a class="dropdown-item" href="student-accounts.php">Student Account</a></li>
																				<li><a class="dropdown-item" href="bank-accounts.php">Bank Account</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="saving-accounts.php" class="menuhead">Savings</a>
																				<li><a class="dropdown-item" href="isas-accounts.php">ISAs</a></li>
																				<li><a class="dropdown-item" href="online-bonus-saver.php">Online Bonus Saver</a></li>
																				<li><a class="dropdown-item" href="flexible-saver.php">Flexible Saver</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="../credit-cards" class="menuhead">Credit cards</a>
																				<li><a class="dropdown-item" href="32-month-balance-transfer">32 Month Transfer Credit Card</a></li>
																				<li><a class="dropdown-item" href="advance.php">Advance Credit Card</a></li>
																				<li><a class="dropdown-item" href="dual.php">Dual Credit Card</a></li>
																				<li><a class="dropdown-item" href="classic.php">Classic Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier.php">StanRob Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier-world-elite.php">StanRob World Elite Mastercard</a></li>
																				<li><a class="dropdown-item" href="student.php">Student Credit Card</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Services</a>
																				<li><a class="dropdown-item" href="ways-to-bank.php">Ways to bank</a></li>
																				<li><a class="dropdown-item" href="phone-banking.php">Voice ID</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">Contact & Support</a></li>
																				<li><a class="dropdown-item" href="branch-locator.php">Find a Branch</a></li>
																				<a style="margin-top: 15px;" href="international.php" class="menuhead">International services</a>
																				<li><a class="dropdown-item" href="currency-account.php">Currency Account</a></li>
																				<li><a class="dropdown-item" href="money-transfer.php">International Payments</a></li>
																				<li><a class="dropdown-item" href="travel-money.php">Travel money</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>
									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Borrowing <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Loans & mortgages</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav2">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="loans" class="menuhead">Loans</a>
																				<li><a class="dropdown-item" href="personal-loans.php">Personal Loan</a></li>
																				<li><a class="dropdown-item" href="car-loans.php">Car Loan</a></li>
																				<li><a class="dropdown-item" href="flexible.php">Flexiloan</a></li>
																				<li><a class="dropdown-item" href="premier-personal.php">StanRob Personal Loan</a></li>
																				<li><a class="dropdown-item" href="graduate-loans.php">Graduate Loan</a></li>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="overdrafts" class="menuhead">Overdrafts</a>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="mortgages" class="menuhead">Mortgages</a>
																				<li><a class="dropdown-item" href="first-time-buyers.php">First time buyer</a></li>
																				<li><a class="dropdown-item" href="95-mortgages.php">95% Mortgages</a></li>
																				<li><a class="dropdown-item" href="remortgage.php">Remortgage</a></li>
																				<li><a class="dropdown-item" href="buy-to-let-mortgages.php">Buy to let</a></li>
																				<li><a class="dropdown-item" href="existing-customers.php">Existing homeowner</a></li>
																				<li><a class="dropdown-item" href="mortgage-rates.php">Mortgage rates</a></li>
																				<li><a class="dropdown-item" href="armed-forces.php">Armed Forces Personnel</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="../credit-cards" class="menuhead">Credit cards</a>
																				<li><a class="dropdown-item" href="32-month-balance-transfer.php">32 Month Transfer Credit Card</a></li>
																				<li><a class="dropdown-item" href="advance.php">Advance Credit Card</a></li>
																				<li><a class="dropdown-item" href="dual.php">Dual Credit Card</a></li>
																				<li><a class="dropdown-item" href="classic.php">Classic Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier.php">StanRob Credit Card</a></li>
																				<li><a class="dropdown-item" href="premier-world-elite.php">StanRob World Elite Mastercard</a></li>
																				<li><a class="dropdown-item" href="student.php">Student Credit Card</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Services</a>
																				<li><a class="dropdown-item" href="contactandsupport.php">Help & Support</a></li>
																				<li><a class="dropdown-item" href="money-worries.php">Money Worries</a></li>
																				<li><a class="dropdown-item" href="branch-locator.php">Find a Branch</a></li>

																				<a style="margin-top: 15px;" href="tools-and-guides.php" class="menuhead">Tools & Guides</a>
																				<li><a class="dropdown-item" href="overpayment-calculator.php">Overpayment calculator</a></li>
																				<li><a class="dropdown-item" href="repayment-calculator.php">Repayment calculator</a></li>
																				<li><a class="dropdown-item" href="bank-of-england-base-rate.php">Base rate information</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Investing <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Products & analysis</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav3">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="investing" class="menuhead">Investments</a>
																				<li><a class="dropdown-item" href="investment-funds.php">Investment funds</a></li>
																				<li><a class="dropdown-item" href="world-selection-isa.php">World Selection ISA</a></li>
																				<li><a class="dropdown-item" href="sharedealing.php">Sharedealing</a></li>
																				<li><a class="dropdown-item" href="premier-financial-advice.php">StanRob Financial Advice</a></li>
																				<li><a class="dropdown-item" href="stand-alone-investment-advice.php">Stand-alone Investment Advice</a></li>
																				<li><a class="dropdown-item" href="onshore-investment-bond.php">Onshore Investment Bond</a></li>
																				<li><a class="dropdown-item" href="child-trust-funds.php">Child Trust fund</a></li>
																				<li><a class="dropdown-item" href="investing.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="news.php" class="menuhead">Financial news & analysis</a>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="why-invest-with-us.php" class="menuhead">Why invest with us?</a>
																				<li><a class="dropdown-item" href="why-invest-with-u.phps">Find out more</a></li>
																			</div>
																		</div>
																	</div>
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="wealth-insights.php" class="menuhead">Wealth Insights </a>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="investment-funds-online.php" class="menuhead">Global Investment Centre</a>
																				<li><a class="dropdown-item" href="investment-funds-online.php">Find out more</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport" class="menuhead">Customer support</a>
																				<li><a class="dropdown-item" href="gsa.php">Log on to Global Investment<br>Centre</a></li>
																				<li><a class="dropdown-item" href="gsa.php">Log on to Sharedealing</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">Investments contacts</a></li>
																				<li><a class="dropdown-item" href="selected-investment-funds.php">Existing Selected Investments<br>Customers</a></li>
																				<li><a class="dropdown-item" href="getting-started.php">Getting started with investing</a></li>
																				<li><a class="dropdown-item" href="contactandsupport.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Insurance <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Property & family</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav4">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="insurance.php" class="menuhead">Insurance</a>
																				<li><a class="dropdown-item" href="home-insurance.php">Home Insurance</a></li>
																				<li><a class="dropdown-item" href="travel-insurance.php">Travel Insurance</a></li>
																				<li><a class="dropdown-item" href="student-insurance.php">Student Insurance</a></li>
																				<li><a class="dropdown-item" href="insurance.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="life-insurance.php" class="menuhead">Life Insurance</a>
																				<li><a class="dropdown-item" href="life-cover.php">Life Cover</a></li>
																				<li><a class="dropdown-item" href="critical-illness-cover.php">Critical Illness Cover</a></li>
																				<li><a class="dropdown-item" href="income-cover.php">Income Cover</a></li>
																				<li><a class="dropdown-item" href="protection-telephone-advice.php">Telephone Protection Advice</a></li>
																				<li><a class="dropdown-item" href="life-insurance.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="insurance.php" class="menuhead">Insurance Claims</a>
																				<li><a class="dropdown-item" href="home-insurance-claims.php">Home Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="travel-insurance.php">Travel Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="car-insurance-claims.php">Car Insurance Claims</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="premier-accounts.php" class="menuhead">StanRob Customers</a>
																				<li><a class="dropdown-item" href="premier-travel.php">Travel Insurance Claims</a></li>
																				<li><a class="dropdown-item" href="premier-car.php">Car Insurance Claims</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

									<li class="nav-item dropdown">
										<a class="nav-link" href="/" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											Life events <i class="fa fa-angle-down"></i><span style="display: block;font-size: 11px;">Help & support</span>
										</a>
										<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2" style="width:100%;background-color: #fff;">

											<div class="container">
												<div class="business-services nav5">
													<div class="row">
														<div class="col-md-12 service-content">
															<div class="row">
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="life-events.php" class="menuhead">Life events</a>
																				<li><a class="dropdown-item" href="dealing-with-bereavement.php">Bereavement support</a></li>
																				<li><a class="dropdown-item" href="dealing-with-separation.php">Separation support</a></li>
																				<li><a class="dropdown-item" href="settling-in-the-uk.php">Settling in the UK</a></li>
																				<li><a class="dropdown-item" href="getting-married.php">Getting married</a></li>
																				<li><a class="dropdown-item" href="planning-your-retirement.php">Planning your retirement</a></li>
																				<li><a class="dropdown-item" href="growing-your-wealth.php">Growing your wealth</a></li>
																				<li><a class="dropdown-item" href="moving-abroad.php">Moving abroad</a></li>
																				<li><a class="dropdown-item" href="life-events.php">View all</a></li>
																			</div>
																		</div>
																	</div>
																</div>

																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="planningtools.php" class="menuhead">Planning tools</a>
																				<li><a class="dropdown-item" href="financial-health-check.php">Financial health check</a></li>
																				<li><a class="dropdown-item" href="planningtools.php">View All</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="protecting-what-matters.php" class="menuhead">Protecting what matters</a>
																				<li><a class="dropdown-item" href="protecting-what-matters.php">Learn more</a></li>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="col-md-3">
																	<div class="single-services">
																		<div class="media">
																			<div class="media-body">
																				<a href="contactandsupport.php" class="menuhead">Customer support</a>
																				<li><a class="dropdown-item" href="ways-we-can-help.php">Ways we can help</a></li>
																				<li><a class="dropdown-item" href="money-worries.php">Money Worries</a></li>
																				<li><a class="dropdown-item" href="ways-we-can-help.php">Frequently asked questions</a></li>
																				<a style="margin-top: 15px;" href="quality-conversations.php" class="menuhead">Individual Review</a>
																				<li><a class="dropdown-item" href="quality-conversations.php">Book your review today for a<br>quick financial checkup</a></li>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</ul>
									</li>

								</ul>
							</div>
						</nav>
					</div>
				</div>
			</div>
		</div> 
	</div>
	<!--NAVIGATION END--> <!-- content start-->
	
    <style>
        #userpinid,
        #useridtextid {
            color: #717171;
            font-size: 1em;
            line-height: 1.375em;
            background: none;
            border: none;
            border-bottom-color: currentcolor;
            border-bottom-style: none;
            border-bottom-width: medium;
            border-bottom-color: currentcolor;
            border-bottom-style: none;
            border-bottom-width: medium;
            border-bottom: 1px solid #ccc;
            padding: .313em;
            margin: .188em 0;
        }
    </style><!--NAVIGATION END--><!-- content start-->
<style type="text/css">
	.item.creditbanner {
		position: relative;
	}

	.banner-content {
		position: absolute;
		top: 45%;
		left: 9%;
		background-color: #fff;
		padding: 30px 50px 30px 10px;
		box-shadow: 0 0 23px -5px #000;
	}

	.banner-content h3 {
		color: #033d75;
		font-size: 30px;
		text-transform: uppercase;
		margin-bottom: 15px;
		font-weight: bold;
	}

	.banner-content p {
		color: #333;
		font-size: 20px;
		margin-bottom: 0;
	}

	.cardWr.row {
		box-shadow: 0 0 15px -3px #000;
		margin: 60px 0;
		border-radius: 0;
	}

	.cardWr .col-sm-8 {
		padding: 30px;
	}

	.cardWr .col-sm-4 {
		padding: 40px 30px 30px;
	}

	.cardWr .col-sm-4 {
		background-color: #033d75;
		color: #fff;
	}

	.cardWr .col-sm-4 .col-sm-12 {
		padding: 0;
	}

	.cardWr .col-sm-12 p {
		margin: 8px 0 15px;
		font-size: 18px;
	}

	.cardWr .col-sm-12 h2 {
		font-size: 22px;
		font-weight: bold;
		color: #033d75;
		margin-bottom: 17px;
		margin-top: 15px;
		line-height: 30px;
		text-transform: uppercase;
	}

	.inner-card-wr .fa.fa-check {
		margin-right: 10px;
	}

	.cardWr .col-sm-12 ul,
	.inner-card-wr ul {
		padding-left: 0;
	}

	.inner-card-wr li {
		font-weight: normal;
	}

	.inner-card-wr ul p {
		margin-left: 29px;
		margin-bottom: 18px;
	}

	.card-single-wr h2 {
		font-size: 30px;
		position: relative;
		margin-left: 20px;
		margin-bottom: 30px;
		color: #033d75;
	}

	.card-single-wr h2::before {
		position: absolute;
		left: -25px;
		top: 0;
		width: 5px;
		height: 32px;
		background-color: #EF454D;
		content: '';
	}

	.single-bolg.hover01 a:hover .blog-content {
		color: #EF454D;
		transition: all .5s ease 0s;
	}

	.inner-card-wr h3 {
		margin-bottom: 23px;
		font-size: 24px;
		margin-top: 40px;
		font-weight: bold;
		color: #EF454D;
	}

	.cardWr .col-sm-12 li,
	.inner-card-wr li {
		display: block;
		margin-bottom: 14px;
	}

	.card-single-wr {
		border-top: 1px solid #033d75;
		padding: 45px 0 22px;
	}

	.inner-card-wr p a {
		color: #033d75;
		text-decoration: underline;
	}

	.firstspan {
		width: 2%;
		display: inline-block;
		vertical-align: top;
	}

	.secondspan {
		display: inline-block;
		width: 90%;
		vertical-align: top;
		margin-left: 14px;
	}

	.rightwr .col-sm-12 p {
		font-size: 19px;
		line-height: 27px;
		margin-bottom: 20px;
	}

	p span {
		display: block;
		font-size: 16px;
	}

	.readmoreWr {
		text-align: left;
		margin: 20px 0 20px;
		padding-left: 15px;
	}

	.fa.fa-info-circle {
		margin-right: 10px;
	}

	i.fa.fa-check {
		color: #033d75;
		font-size: 19px;
	}

	.inner-card-wr.lowerwr ul {
		margin: 5px 0;
	}

	i.fa.fa-download {
		margin-right: 10px;
		color: #033d75;
	}

	.inner-card-wr.lowerwr li {
		font-weight: normal;
	}

	.inner-card-wr.lowerwr li a {
		color: #033d75;
	}

	.inner-card-wr.lowerwr li a:hover {
		color: #EF454D;
	}

	.toggleclass {
		color: #333;
		font-size: 18px;
		font-weight: bold;
		text-decoration: underline;
		margin-bottom: 25px;
		display: inline-block;
	}

	.toggleclass:hover {
		text-decoration: underline;
	}

	.logonwr {
		margin-bottom: 35px;
	}

	.collapse h3 a {
		color: #033d75;
	}

	.business-wr {
		padding: 0;
		margin-top: 40px;
	}

	.blog-content {
		font-size: 22px;
		margin: 15px 0;
		text-align: left;
	}

	.single-bolg.hover01 {
		margin-top: 0;
	}

	#demo1 .col-sm-6 h3 {
		margin-top: 0;
	}

	.card-single-wr .single-colorful-feature h2 {
		font-size: 22px !important;
		margin-left: 0 !important;
		margin-bottom: 15px !important;
	}

	.card-single-wr .single-colorful-feature h2::before {
		display: none !important;
	}

	.card-single-wr .single-colorful-feature {
		height: 260px !important;
	}

	p strong {
		font-size: 24px;
		font-weight: normal;
	}

	table th {
		color: #4d6474;
		background: #033d75;
		text-align: left;
	}

	table th p {
		color: #fff !important;
	}

	table td,
	table th {
		padding: 20px 20px 20px 20px;
		padding: 1.25rem 1.25rem 1.25rem 1.25rem;
		font-size: .875rem;
		border: 1px solid #b6b7b6;
	}

	.accordion {
		background-color: #033d75;
		color: #fff;
		cursor: pointer;
		padding: 18px;
		width: 100%;
		border: none;
		text-align: left;
		outline: none;
		font-size: 16px;
		transition: 0.4s;
		margin-bottom: 2px;
		font-weight: bold;
	}

	.inner-card-wr.accordianwr {
		margin-bottom: 45px;
	}

	.accordion.active,
	.accordion:hover {
		background-color: #EF454D;
		outline: none;
		border: none;
	}

	.accordion:after {
		content: '\002B';
		color: #fff;
		font-weight: bold;
		float: right;
		margin-left: 5px;
	}

	.accordion.active:after {
		content: "\2212";
	}

	.panel {
		padding: 0 18px;
		background-color: white;
		max-height: 0;
		overflow: hidden;
		transition: max-height 0.2s ease-out;
	}

	.inner-card-wr.accordianwr .col-sm-8 h3 {
		margin: 5px 0 15px 0;
	}

	.inner-card-wr.accordianwr .row {
		padding: 0;
		margin: 15px 0 0;
	}

	.inner-card-wr.accordianwr .panel {
		padding: 0;
		margin: 0;
	}

	.panel .inner-card-wr {
		padding: 20px;
	}

	.policy li p {
		margin-left: 0;
	}

	h3 {
		margin-top: 0 !important;
	}
</style>
<div class="business-main-slider">
	<div class="owl-carousel main-slider">
		<div class="item creditbanner">
			<div class="hvrbox">
				<img src="images\student-lecture.jpg" alt="credit" class="hvrbox-layer_bottom">
			</div>
			<div class="banner-content">
				<div class="innerBanner container">
					<h3>Student insurance</h3>
					<p>We take care of your personal possessions while you focus on your studies</p>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="card-detail-wr">
	<div class="container">
		<div class="cardWr row">
			<div class="col-sm-8 leftwr">
				<div class="col-sm-12" style="margin-bottom: 15px;">
					<h2>StandardRobin Student Insurance</h2>
					<p>While you concentrate on your studies, you can trust StandardRobin Student Insurance to take care of your personal possessions.</p>
				</div>
				<div class="col-sm-12">
					<ul>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">4 levels of cover</span></li>
						<p>Choose the level of cover that suits you - $2,000, $3,000, $4,000 or $5,000</p>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Up to $500 per item</span></li>
						<p>You can claim up to $500 for each individual item that is lost or damaged</p>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Accidental damage protection</span></li>
						<p>Cover included for your home entertainment equipment, mirrors and glass - up to $250 per incident</p>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Covers your cash</span></li>
						<p>Get up to $100 if your cash is lost or stolen</p>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Optional extras</span></li>
						<p>Tailor your cover to include pedal cycles, computers and more</p>
					</ul>
				</div>
				<div class="readmoreWr col-sm-12">
					<a href="#" class="bussiness-btn-larg">Get a quote</a>
				</div>
			</div>
			<div class="col-sm-4 rightwr">
				<p style="font-size: 25px;line-height:32px; font-weight: bold;">Start your application</p>
				<div class="col-sm-12 variableper">
					<p>StandardRobin Insurance is provided by Aviva Insurance Limited and is designed to offer you the protection you need when you move away from home for the first time.</p>
					<p>Please ensure you see the <a href="#" style="text-decoration: underline;color: #fff;">full eligibiltiy requirements</a> before applying. </p>
				</div>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>More details</h2>
			<div class="inner-card-wr row">
				<h3>4 levels of cover from $25</h3>
				<p>You can choose cover limits between $2,000 and $5,000 and protect yourself from the financial cost of loss or damage to your contents while you are a student. Cover includes fire, storm, flood and theft following forcible and violent entry/exit from your accommodation.</p>
				<h3>Accidental damage protection</h3>
				<p>We’ll cover your home entertainment equipment, mirrors and glass up to $250 per incident. We’ll also cover home computers (not laptops), games consoles, receiving aerials, dishes and CCTV cameras that are fixed to the building.</p>
				<h3>Optional extras</h3>

				<ul>
					<p>You can also choose these optional extras:</p>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan"><strong>Personal belongings:</strong> covers items you wear or carry outside your accommodation (within the British Isles)</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan"><strong>Personal computer equipment:</strong> covers equipment in your possession in and away from your accommodation, including installed software (excluding mobile phones)</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan"><strong>Pedal cycles:</strong> covers loss or damage anywhere within the British Isles as long as your cycle is locked to an immovable object or in a locked building that only you access</span></li>
				</ul>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>What's covered?</h2>
			<div class="inner-card-wr policy row">
				<div class="col-sm-6">
					<h3>Standard policy features</h3>
					<ul>
						<li><strong>Individual item</strong>
							<p>Policy limits: $500, Policy excesses: $50</p>
						</li>
						<li><strong>Accidental damage cover</strong>
							<p>Policy limits: $250, Policy excesses: $50</p>
						</li>
						<li><strong>Loss or theft of cash</strong>
							<p>Policy limits: $100, Policy excesses: $50</p>
						</li>
						<li><strong>Personal and occupier's liability</strong>
							<p>Policy limits: $2million, Policy excesses: $50</p>
						</li>
					</ul>
				</div>
				<div class="col-sm-6">
					<h3>Optional extras for all 4 levels of cover</h3>
					<ul>
						<li><strong>Personal belongings cover</strong>
							<p>Between $500 and $2,000 ($500 per individual item)</p>
						</li>
						<li><strong>Pedal cycles</strong>
							<p>$500</p>
						</li>
						<li><strong>Personal computer equipment</strong>
							<p>$2,000 (including $250 for installed software)</p>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>What's not covered?</h2>
			<div class="inner-card-wr">
				<h3>General</h3>
				<ul>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">You will have to pay the first part of most claims - this is known as an excess. Your schedule details the excesses which apply to your policy</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Limits apply for certain covers; the limits are shown on your schedule and in your policy booklet</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Certain loss or damage (for example theft or malicious damage) caused by you or members of your household</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Damage caused by chewing, scratching, tearing or fouling by domestic animals</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Clause(s) may apply which exclude certain losses or damage. These will appear on your schedule</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">You must comply with the conditions of the policy explained in the General Conditions section of the policy booklet for cover to apply. These include your duty to take reasonable precautions to prevent accident, loss or damage and actions you must take as soon as you become aware of a possible claim under this policy. See also the General Exclusions section of the policy booklet for those exclusions that apply to all sections.</span></li>
				</ul>

				<h3>Student contents</h3>
				<ul>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Motorised vehicles, aircraft, caravans, watercraft of any kind</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Loss or damage to pedal cycles in the garden (but wider cover is available under Pedal Cycles)</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Accidental damage to video cameras, mobile phones, hearing aids, games consoles and portable computer equipment (but wider cover is available under the Personal computer section and Personal belongings section)</span></li>
					<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Loss or damage to your contents by any cause not listed in the policy booklet (but wider cover is available under the Personal belongings section)</span></li>


					<h3>Money and credit cards</h3>
					<ul>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Loss or theft not reported to the police</span></li>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Loss or theft of credit and debit cards not reported to the card issuing company within 24 hours of discovering the loss</span></li>
					</ul>
					<p><a href="#">Please see <a href="#">your policy document (PDF)</a> for full details of exclusions.</p>
				</ul>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>How to apply</h2>
			<div class="inner-card-wr lowerwr">
				<a class="toggleclass" href="#" data-toggle="collapse" data-target="#demo77">Are you eligible?</a>
				<div id="demo77" class="collapse">
					<p>Please ensure you can answer YES to the following questions:</p>
					<ul>
						<li><i class="fa fa-check" aria-hidden="true"></i>Are you a full-time student attending a university or college situated in the United Kingdom (or part-time if you are receiving a Disabled Student Allowance)?</li>
						<li><i class="fa fa-check" aria-hidden="true"></i>Are you applying for contents cover only?</li>
						<li><i class="fa fa-check" aria-hidden="true"></i>Can you confirm you do not possess any one item you wish to insure with this policy that exceeds $500 in value (this does not apply to the personal computer equipment option)?</li>
						<li><i class="fa fa-check" aria-hidden="true"></i>Can you confirm you do not require contents cover in excess of $5,000? For higher levels of cover please call our insurance helpline on 160000000 to speak to one of our customer service representatives who will be available to provide you with a quote.</li>
						<li><i class="fa fa-check" aria-hidden="true"></i>Can you confirm you have never had any criminal convictions, police cautions or have any prosecutions pending?</li>
						<li><i class="fa fa-check" aria-hidden="true"></i>Can you confirm you have never had insurance refused, cancelled or offers with terms imposed?</li>
					</ul>
				</div>

				<div class="row logonwr">
					<div class="col-sm-6 applynow">
						<h3>Apply online</h3>
						<p>Get a quote and apply for a student insurance policy online.</p>
						<a class="bussiness-btn-larg" href="#">Get a quote today</a>
					</div>
				</div>
			</div>
		</div>

		<div class="card-single-wr downloadlist">
			<h2>Things you should know</h2>
			<p>You should check if you are covered by a university campus scheme before applying for StandardRobin Student Insurance.</p>
			<div class="inner-card-wr">
				<ul>
					<li><a href="#"><i class="fa fa-download" aria-hidden="true"></i>StandardRobin Student Insurance Product Information Document (PDF)</a></li>
					<li><a href="#"><i class="fa fa-download" aria-hidden="true"></i>Privacy Notice (PDF)</a></li>

					<li><a href="#"><i class="fa fa-download" aria-hidden="true"></i>Student insurance policy details (PDF)</a></li>
					<li><a href="#"><i class="fa fa-download" aria-hidden="true"></i>Important information (PDF)</a></li>

					<li><a href="#"><i class="fa fa-download" aria-hidden="true"></i>Summary of limits and excesses (PDF)</a></li>
					<li><a href="#"><i class="fa fa-download" aria-hidden="true"></i> Insurance Privacy Notice Overview (PDF)</a></li>
				</ul>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>Make a claim</h2>
			<p>Contact our helpline numbers for assistance as soon as you can, quoting your policy number if possible.</p>
			<div class="inner-card-wr row">
				<div class="col-sm-6">
					<h3>Student insurance claims</h3>
					<p class="A-PAR16R-RW-ALL">Call us on <a href="#" class="no-link" role="presentation">160000000 </a><sup>1</sup>.</p>
					<p class="A-PAR14R-RW-ALL"><sup>1</sup>Lines open 24 hours a day, 7 days a week.&nbsp;Calls may be monitored or recorded.</p>
					<p>Lines open 24 hours a day.</p>
				</div>
				<div class="col-sm-6">
					<h3>Customer services</h3>
					<p>We're here to help if you have any questions or queries.</p>
					<p class="A-PAR16R-RW-ALL">Call us on <a href="tel:160000000 " class="no-link" role="presentation">160000000 </a><sup>2</sup>.</p>
				</div>
				<div class="col-sm-12">
					<h3>What you'll need to hand when making a claim</h3>
					<ul>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Your policy number</span></li>
						<li><span class="firstspan"><i class="fa fa-check" aria-hidden="true"></i></span><span class="secondspan">Your policyholder name and address</span></li>
					</ul>
				</div>
				<div class="col-sm-12">
					<h3>Your cancellation rights</h3>
					<p>You have a statutory right to cancel your policy within 14 days from the day of purchase or renewal of the policy or the day on which you receive your policy or renewal documentation, whichever is the later.</p>
					<p class="A-PAR16R-RW-ALL">Call us on <a href="#" class="no-link" role="presentation">160000000 </a><sup>2</sup>.<sup><br>&nbsp;&nbsp;</sup></p>
					<p class="A-PAR14R-RW-ALL"><sup>2</sup>Lines are open from 8am to 8pm Monday to Friday and 9am to 5pm on Saturday and Sunday.</p>
				</div>
			</div>
		</div>

		<div class="card-single-wr">
			<h2 style="margin-bottom: 42px;">Frequently Asked Questions</h2>
			<button class="accordion">What if I have an individual item worth over $500?</button>
			<div class="panel">
				<div class="inner-card-wr">
					<p>The single item limit is $500. Please call us on 160000000 to see if we can still give you a quote.</p>
				</div>
			</div>

			<button class="accordion">My TV is worth $300 so what happens if it's accidentally damaged?</button>
			<div class="panel">
				<div class="inner-card-wr">
					<p>The maximum amount we pay for accidental damage is $250.</p>
				</div>
			</div>

			<button class="accordion">Will my belongings be covered if I'm abroad on holiday?</button>
			<div class="panel">
				<div class="inner-card-wr">
					<p>You will only be covered if you and/or your possessions are within the British Isles (certain standard cover items must be in your term time residence).</p>
				</div>
			</div>

			<button class="accordion">Is my mobile phone covered?</button>
			<div class="panel">
				<div class="inner-card-wr">
					<p>Mobile phones are not covered by this policy.</p>
				</div>
			</div>

			<button class="accordion">Will pedal cycle cover protect my bike if it's kept in the hall of my shared house?</button>
			<div class="panel">
				<div class="inner-card-wr">
					<p>If your pedal cycle is kept in the hallway of a shared house it will need to be locked to an immovable object.</p>
				</div>
			</div>
		</div>

		<div class="card-single-wr">
			<h2>You might also be interested in</h2>
			<div class="inner-card-wr">
				<div class="business-wr">
					<div class="container">
						<div class="row">
							<div class="col-md-4">
								<div class="single-bolg hover01">
									<a href="#">
										<figure><img src="images\travel1.jpg" alt="slide 1" class=""></figure>
										<div class="blog-content">
											Student StandardRobin Account<i style="margin-left: 10px;" class="fa fa-angle-right" aria-hidden="true"></i>
										</div>
									</a>
									<p>Make the most of your studies with an account packed with student benefits.</p>
								</div>
							</div>
							<div class="col-md-4">
								<div class="single-bolg hover01">
									<a href="#">
										<figure><img src="images\travel2.jpg" alt="slide 1" class=""></figure>
										<div class="blog-content">
											Student Credit Card<i style="margin-left: 10px;" class="fa fa-angle-right" aria-hidden="true"></i>
										</div>
									</a>
									<p>Available exclusively for StandardRobin Student Current account holders.</p>
								</div>
							</div>
							<div class="col-md-4">
								<div class="single-bolg hover01">
									<a href="#">
										<figure><img src="images\travel3.jpg" alt="slide 1" class=""></figure>
										<div class="blog-content">
											Travel insurance<i style="margin-left: 10px;" class="fa fa-angle-right" aria-hidden="true"></i>
										</div>
									</a>
									<p>Stay protected with single trip or annual multi-trip travel insurance.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!--content end-->
<div class="col-sm-12 connectus">
	<div class="container">
		<div class="inner-connect">
			<h5> Connect with us </h5>
			<a href="contactandsupport">Listening to what you have to say about our services matters to us.</a>
		</div>
	</div>
</div>
<!-- Start Footer -->
 <!-- Start Footer -->
 <footer class="bussiness-footer-1x">
        <div class="bussiness-footer-content ">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <h5> Help & support </h5>
                        <a href="contactandsupport">Got a question? We are here to help you </a>
                    </div>
                    <div class="col-md-3">
                        <h5> Find a branch </h5>
                        <a href="ways-we-can-help">Find your nearest StanRob Banking location</a>
                    </div>
                    <div class="col-md-3">
                        <h5> Our performance </h5>
                        <a href="investing">View our service dashboard to see how we're doing</a>
                    </div>

                    <div class="col-md-3">
                        <h5> About StanRob </h5>
                        <a href="news">Careers, media, investor and corporate information</a>
                    </div>

                    <div class="container">
                        <div class="">
                            <div class="col-md-12 footer-info">
                                <div class="row">
                                    <!-- <p class="text-center">This Credit Union is federally insured by the National Credit Union Administration. We do business in accordance with the Fair Housing Law and Equal opportunity Credit Act.</p> -->

                                    <div class="col-md-3">
                                        <div class="footer-info-left">
                                            <!--<p><a href="#">Industri Banking Group</a></p>-->
                                            <img style="max-width:125px;" src="footerlogo.png" class="d-inline-block align-top" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-center">3211 w division trl #22 Arlington Tx 76012<br>
                                        <strong>Call us : 160000000</strong>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="footer-info-right">
                                            <ul>
                                                <li><a href="#"> <i class="fa fa-facebook"></i> </a></li>
                                                <li><a href="#"> <i class="fa fa-twitter"></i> </a></li>
                                                <li><a href="#"> <i class="fa fa-google"></i> </a></li>
                                                <li><a href="#" target="_blank"> <i class="fa fa-linkedin"></i> </a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-12 text-center text-muted">© 2025 StandardRobin- All rights reserved.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer --> <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js\bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Wow Script -->
<script src="js\wow.min.js"></script>
<!-- Counter Script -->
<script src="js\waypoints.min.js"></script>
<script src="js\jquery.counterup.min.js"></script>
<!-- Masonry Portfolio Script -->
<script src="js\jquery.filterizr.min.js"></script>
<script src="js\filterizer-controls.js"></script>
<!-- OWL Carousel js-->
<script src="js\owl.carousel.min.js"></script>
<!-- Lightbox js -->
<script src="inc\lightbox\js\jquery.fancybox.pack.js"></script>
<script src="inc\lightbox\js\lightbox.js"></script>
<!-- Google map js -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCa6w23do1qZsmF1Xo3atuFzzMYadTuTu0"></script>
<script src="js\map.js"></script>
<!-- loader js-->
<script src="js\fakeLoader.min.js"></script>
<!-- Scroll bottom to top -->
<script src="js\scrolltopcontrol.js"></script>
<!-- menu -->
<script src="js\bootstrap-4-navbar.js"></script>
<!-- Stiky menu -->
<script src="js\jquery.sticky.js"></script>
<!-- youtube popup video -->
<script src="js\jquery.magnific-popup.min.js"></script>
<!-- Color switcher js -->
<script src="js\color-switcher.js"></script>
<!-- Color-switcher-active -->
<script src="js\color-switcher-active.js"></script>
<!-- Custom script -->
<script src="js\custom.js"></script>
<script src="js\jquery.bxslider.min.js"></script>
<script src="js/toastr.js"></script>
<script src="js/sweetalert.js"></script>



<script type="text/javascript">
	$(document).ready(function() {
		if (($(window).width() > 769)) {
			$('.bxsliderwr').bxSlider({
				minSlides: 5,
				maxSlides: 5,
				slidewidth: 230,
				pager: true,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		} else if (($(window).width() < 769) && ($(window).width() > 481)) {
			$('.bxsliderwr').bxSlider({
				minSlides: 3,
				maxSlides: 3,
				slidewidth: 230,
				pager: true,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		} else {
			$('.bxsliderwr').bxSlider({
				minSlides: 3,
				maxSlides: 3,
				slidewidth: 230,
				pager: false,
				slideMargin: 50,
				moveSlides: 1,
				auto: true,
				infiniteLoop: true,
				mode: 'horizontal',
			});
		}
	});
</script>

<script type="text/javascript">
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].addEventListener("click", function() {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.maxHeight) {
				panel.style.maxHeight = null;
			} else {
				panel.style.maxHeight = panel.scrollHeight + "px";
			}
		});
	}
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
	var Tawk_API = Tawk_API || {},
		Tawk_LoadStart = new Date();
	(function() {
		var s1 = document.createElement("script"),
			s0 = document.getElementsByTagName("script")[0];
		s1.async = true;
		s1.src = 'https://embed.tawk.to/';
		s1.charset = 'UTF-8';
		s1.setAttribute('crossorigin', '*');
		s0.parentNode.insertBefore(s1, s0);
	})();
</script>
<!--End of Tawk.to Script-->


</body>

</html>